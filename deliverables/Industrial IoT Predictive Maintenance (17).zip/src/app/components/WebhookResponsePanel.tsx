import { useRef, useEffect } from "react";

export interface WebhookResponse {
  id: string;
  machineId: string;
  timestamp: number;
  status: number;
  body: any;
}

interface WebhookResponsePanelProps {
  responses: WebhookResponse[];
}

const FONT = "'Inter', sans-serif";
const MONO = "'JetBrains Mono', monospace";

function formatTime(ts: number) {
  const d = new Date(ts);
  const h12 = (d.getHours() % 12 || 12).toString();
  const m = d.getMinutes().toString().padStart(2, "0");
  const s = d.getSeconds().toString().padStart(2, "0");
  const ampm = d.getHours() >= 12 ? "PM" : "AM";
  return `${h12}:${m}:${s} ${ampm}`;
}

function getActionInfo(body: any): { action: string; label: string; reasoning: string[]; color: string; bgColor: string; borderColor: string } | null {
  if (!body || typeof body !== "object" || !body.action) return null;
  const action = body.action as string;
  const reasoning = Array.isArray(body.reasoning) ? body.reasoning : [];

  if (action === "maintenance scheduled") {
    return { action, label: "MAINTENANCE SCHEDULED", reasoning, color: "#ff3355", bgColor: "rgba(255,51,85,0.08)", borderColor: "#ff3355" };
  } else if (action === "alerted") {
    return { action, label: "ALERTED", reasoning, color: "#ffcc00", bgColor: "rgba(255,204,0,0.08)", borderColor: "#ffcc00" };
  } else {
    return { action, label: "FALSE ALARM", reasoning, color: "#00ff88", bgColor: "rgba(0,255,136,0.08)", borderColor: "#00ff88" };
  }
}

export function WebhookResponsePanel({ responses }: WebhookResponsePanelProps) {
  // Only show valid n8n responses (status 2xx with action field) — hide errors/unreachable
  const validResponses = responses.filter(
    (r) => r.status >= 200 && r.status < 300 && r.body && typeof r.body === "object" && r.body.action
  );

  if (validResponses.length === 0) return null;

  return (
    <div
      className="rounded-md p-4 mt-4"
      style={{ backgroundColor: "#111418", border: "1px solid #1a1f28" }}
    >
      <div className="flex items-center gap-2.5 mb-4">
        <div
          style={{
            width: 6,
            height: 6,
            borderRadius: "50%",
            backgroundColor: "#00aaff",
            boxShadow: "0 0 8px rgba(0,170,255,0.4)",
          }}
        />
        <span style={{ fontFamily: FONT, fontWeight: 600, color: "#e2e8f0", fontSize: 14, letterSpacing: 0.5 }}>
          RESPONSES
        </span>
        <span
          className="px-1.5 py-0.5 rounded"
          style={{
            fontFamily: MONO,
            fontSize: 10,
            fontWeight: 500,
            backgroundColor: "rgba(0,170,255,0.1)",
            color: "#00aaff",
            border: "1px solid rgba(0,170,255,0.25)",
          }}
        >
          {validResponses.length}
        </span>
      </div>

      <div className="flex flex-col gap-3 max-h-[480px] overflow-y-auto pr-1" style={{ scrollbarWidth: "thin", scrollbarColor: "#1e2530 transparent", overscrollBehavior: "contain", willChange: "scroll-position" }}>
        {validResponses.map((r) => {
          const isOk = r.status >= 200 && r.status < 300;
          const actionInfo = getActionInfo(r.body);
          const accentColor = actionInfo ? actionInfo.borderColor : (isOk ? "#00ff88" : "#ff3355");
          const responseMachineId = r.body?.machine_id || r.machineId;

          return (
            <div
              key={r.id}
              className="rounded-md"
              style={{
                backgroundColor: "#0d1015",
                border: `1px solid ${accentColor}20`,
                borderLeft: `3px solid ${accentColor}`,
                overflow: "hidden",
              }}
            >
              {/* Header row */}
              <div
                className="flex items-center gap-2 px-4 py-2.5"
                style={{
                  borderBottom: `1px solid ${accentColor}15`,
                  backgroundColor: actionInfo ? actionInfo.bgColor : (isOk ? "rgba(0,255,136,0.04)" : "rgba(255,51,85,0.04)"),
                }}
              >
                <span
                  className="px-2 py-0.5 rounded"
                  style={{
                    fontFamily: MONO,
                    fontSize: 11,
                    fontWeight: 700,
                    backgroundColor: `${accentColor}18`,
                    color: "#00aaff",
                    border: `1px solid ${accentColor}30`,
                    letterSpacing: 0.5,
                  }}
                >
                  {responseMachineId}
                </span>
                <span
                  className="px-2 py-0.5 rounded"
                  style={{
                    fontFamily: MONO,
                    fontSize: 10,
                    fontWeight: 600,
                    backgroundColor: isOk ? "rgba(0,255,136,0.12)" : "rgba(255,51,85,0.12)",
                    color: isOk ? "#00ff88" : "#ff3355",
                    letterSpacing: 0.5,
                  }}
                >
                  HTTP {r.status}
                </span>
                <span
                  style={{
                    fontFamily: MONO,
                    fontSize: 10,
                    color: "#4a5568",
                    marginLeft: "auto",
                    whiteSpace: "nowrap",
                  }}
                >
                  {formatTime(r.timestamp)}
                </span>
              </div>

              {/* n8n Decision — enlarged display */}
              {actionInfo ? (
                <div className="px-4 py-3">
                  {/* Action badge — large */}
                  <div className="flex items-center gap-2.5 mb-3">
                    <div
                      style={{
                        width: 8,
                        height: 8,
                        borderRadius: "50%",
                        backgroundColor: actionInfo.color,
                        boxShadow: `0 0 10px ${actionInfo.color}60`,
                        flexShrink: 0,
                      }}
                    />
                    <span
                      style={{
                        fontFamily: FONT,
                        fontSize: 13,
                        fontWeight: 700,
                        color: actionInfo.color,
                        letterSpacing: 0.8,
                      }}
                    >
                      {actionInfo.label}
                    </span>
                  </div>

                  {/* Reasoning steps — enlarged */}
                  {actionInfo.reasoning.length > 0 && (
                    <div
                      className="rounded-md px-3 py-2.5"
                      style={{
                        backgroundColor: `${actionInfo.color}08`,
                        border: `1px solid ${actionInfo.color}18`,
                      }}
                    >
                      <div
                        className="mb-2"
                        style={{
                          fontFamily: MONO,
                          fontSize: 9,
                          fontWeight: 600,
                          color: "#4a5568",
                          letterSpacing: 1,
                          textTransform: "uppercase",
                        }}
                      >
                        Reasoning
                      </div>
                      {actionInfo.reasoning.map((step, i) => (
                        <div
                          key={i}
                          className="flex items-start gap-2.5"
                          style={{
                            marginTop: i > 0 ? 8 : 0,
                          }}
                        >
                          <span
                            className="flex-shrink-0 flex items-center justify-center rounded"
                            style={{
                              width: 18,
                              height: 18,
                              backgroundColor: `${actionInfo.color}15`,
                              color: actionInfo.color,
                              fontFamily: MONO,
                              fontSize: 10,
                              fontWeight: 700,
                              marginTop: 1,
                            }}
                          >
                            {i + 1}
                          </span>
                          <span
                            style={{
                              fontFamily: FONT,
                              fontSize: 12,
                              color: "#cbd5e1",
                              lineHeight: 1.55,
                            }}
                          >
                            {step}
                          </span>
                        </div>
                      ))}
                    </div>
                  )}

                  {/* Machine ID from response */}
                  {r.body?.machine_id && (
                    <div
                      className="mt-2.5"
                      style={{ fontFamily: MONO, fontSize: 10, color: "#4a5568" }}
                    >
                      machine_id: <span style={{ color: "#64748b" }}>{r.body.machine_id}</span>
                    </div>
                  )}
                </div>
              ) : (
                /* Fallback: raw JSON body for non-n8n responses */
                <div className="px-4 py-3">
                  <pre
                    style={{
                      fontFamily: MONO,
                      fontSize: 11,
                      color: "#94a3b8",
                      margin: 0,
                      whiteSpace: "pre-wrap",
                      wordBreak: "break-all",
                      maxHeight: 160,
                      overflow: "auto",
                      lineHeight: 1.6,
                    }}
                  >
                    {typeof r.body === "string" ? r.body : JSON.stringify(r.body, null, 2)}
                  </pre>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}