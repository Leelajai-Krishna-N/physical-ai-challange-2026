import { ServerReading, MachineId, MACHINE_LABELS } from "./simulation";
import { Sparkline } from "./Sparkline";
import type { MachineState, HealthStage, MetricKey, CompoundSignature } from "./math-engine";
import type { N8nDecision } from "../App";

const FONT = "'Inter', sans-serif";
const MONO = "'JetBrains Mono', monospace";

interface MachineCardProps {
  machineId: MachineId;
  reading: ServerReading | null;
  sparkData: number[];
  connected: boolean;
  stopped?: boolean;
  engineState?: MachineState | null;
  n8nDecision?: N8nDecision | null;
}

const statusColors: Record<string, { bg: string; text: string; border: string }> = {
  running: { bg: "rgba(0,255,136,0.1)", text: "#00ff88", border: "#00ff88" },
  warning: { bg: "rgba(255,204,0,0.1)", text: "#ffcc00", border: "#ffcc00" },
  fault:   { bg: "rgba(255,51,85,0.15)", text: "#ff3355", border: "#ff3355" },
  stopped: { bg: "rgba(100,100,100,0.15)", text: "#666", border: "#444" },
};

const healthColors: Record<HealthStage, { color: string; bg: string }> = {
  healthy:  { color: "#00ff88", bg: "rgba(0,255,136,0.1)" },
  aging:    { color: "#ffcc00", bg: "rgba(255,204,0,0.1)" },
  degraded: { color: "#ff8844", bg: "rgba(255,136,68,0.1)" },
  critical: { color: "#ff3355", bg: "rgba(255,51,85,0.1)" },
};

const phaseLabels: Record<string, string> = {
  startup: "STARTUP", steady: "STEADY", high_load: "HI-LOAD", low_load: "LO-LOAD",
};

export function MachineCard({ machineId, reading, sparkData, connected, stopped, engineState, n8nDecision }: MachineCardProps) {
  const status = stopped ? "stopped" : (reading?.status || "running");
  const sc = statusColors[status] || statusColors.running;
  const isFault = status === "fault";
  const sparkColor = stopped ? "#444" : status === "fault" ? "#ff3355" : status === "warning" ? "#ffcc00" : "#00ff88";

  const es = engineState;
  const hc = es ? healthColors[es.health_stage] : null;
  const activeSigs = es?.compound_signatures?.filter((s) => s.active) || [];

  return (
    <div
      className="border rounded-md p-4 relative"
      style={{
        backgroundColor: "#111418",
        borderColor: sc.border + "40",
        animation: isFault ? "pulse-border 2s ease-in-out infinite" : undefined,
        opacity: stopped ? 0.5 : 1,
      }}
    >
      {stopped && (
        <div
          className="absolute inset-0 flex items-center justify-center z-10 rounded-md"
          style={{ backgroundColor: "rgba(10,12,16,0.85)" }}
        >
          <div className="text-center">
            <div style={{ fontFamily: FONT, fontWeight: 700, color: "#ff3355", fontSize: 16, letterSpacing: 1.5 }}>
              {es?.power_state === "SHUTDOWN" ? "■ SHUTDOWN" : "■ MACHINE HALTED"}
            </div>
            <div style={{ fontFamily: MONO, color: "#4a5568", fontSize: 11, marginTop: 6 }}>
              Maintenance confirmed — stream disconnected
            </div>
          </div>
        </div>
      )}

      {/* Header */}
      <div className="flex items-center justify-between mb-2">
        <div>
          <div style={{ fontFamily: FONT, fontWeight: 600, color: "#e2e8f0", fontSize: 14 }}>
            {MACHINE_LABELS[machineId]}
          </div>
          <div className="flex items-center gap-2" style={{ fontFamily: MONO, color: "#4a5568", fontSize: 10, marginTop: 2 }}>
            /stream/{machineId}
            <span
              className="inline-block w-1.5 h-1.5 rounded-full"
              style={{ backgroundColor: connected ? "#00ff88" : "#ff3355" }}
            />
          </div>
        </div>
        <div className="flex flex-col items-end gap-1">
          <span
            className="px-2 py-0.5 rounded uppercase"
            style={{
              backgroundColor: sc.bg,
              color: sc.text,
              border: `1px solid ${sc.border}40`,
              fontFamily: MONO,
              fontSize: 10,
              fontWeight: 600,
              letterSpacing: 0.5,
            }}
          >
            {status}
          </span>
          {/* Priority rank badge */}
          {es && es.priority_rank > 0 && es.risk_score >= 25 && (
            <span
              className="px-1.5 py-0.5 rounded"
              style={{
                fontFamily: MONO,
                fontSize: 9,
                fontWeight: 600,
                backgroundColor: es.is_top_ticket ? "rgba(255,51,85,0.15)" : "rgba(255,204,0,0.1)",
                color: es.is_top_ticket ? "#ff3355" : "#ffcc00",
                border: `1px solid ${es.is_top_ticket ? "rgba(255,51,85,0.3)" : "rgba(255,204,0,0.25)"}`,
              }}
            >
              {es.is_top_ticket ? "★ TOP TICKET" : `RANK #${es.priority_rank}`}
            </span>
          )}
        </div>
      </div>

      {/* Risk / Health / Phase / RUL row */}
      {es && !stopped && (
        <div className="flex items-center gap-2 mb-2 flex-wrap">
          {/* Health stage */}
          <span
            className="px-1.5 py-0.5 rounded"
            style={{
              fontFamily: MONO, fontSize: 9, fontWeight: 600,
              backgroundColor: hc?.bg || "transparent",
              color: hc?.color || "#4a5568",
              border: `1px solid ${(hc?.color || "#4a5568")}30`,
              letterSpacing: 0.5,
            }}
          >
            {es.health_stage.toUpperCase()}
          </span>
          {/* Operating phase */}
          <span
            className="px-1.5 py-0.5 rounded"
            style={{
              fontFamily: MONO, fontSize: 9, fontWeight: 500,
              backgroundColor: "rgba(100,160,255,0.08)",
              color: "#6495ed",
              border: "1px solid rgba(100,149,237,0.2)",
            }}
          >
            {phaseLabels[es.operating_phase] || es.operating_phase}
          </span>
          {/* Risk score */}
          <span
            className="px-1.5 py-0.5 rounded"
            style={{
              fontFamily: MONO, fontSize: 9, fontWeight: 600,
              backgroundColor: es.risk_score >= 75 ? "rgba(255,51,85,0.1)" : es.risk_score >= 50 ? "rgba(255,136,68,0.1)" : es.risk_score >= 25 ? "rgba(255,204,0,0.08)" : "rgba(0,255,136,0.06)",
              color: es.risk_score >= 75 ? "#ff3355" : es.risk_score >= 50 ? "#ff8844" : es.risk_score >= 25 ? "#ffcc00" : "#00ff88",
              border: `1px solid ${es.risk_score >= 75 ? "rgba(255,51,85,0.25)" : es.risk_score >= 50 ? "rgba(255,136,68,0.25)" : es.risk_score >= 25 ? "rgba(255,204,0,0.2)" : "rgba(0,255,136,0.15)"}`,
            }}
          >
            RISK {es.risk_score.toFixed(1)}%
          </span>
          {/* RUL */}
          {es.remaining_life_minutes !== Infinity && (
            <span
              className="px-1.5 py-0.5 rounded"
              style={{
                fontFamily: MONO, fontSize: 9, fontWeight: 600,
                backgroundColor: es.remaining_life_minutes < 60 ? "rgba(255,51,85,0.1)" : "rgba(255,204,0,0.08)",
                color: es.remaining_life_minutes < 60 ? "#ff3355" : "#ffcc00",
                border: `1px solid ${es.remaining_life_minutes < 60 ? "rgba(255,51,85,0.25)" : "rgba(255,204,0,0.2)"}`,
              }}
            >
              RUL {es.remaining_life_minutes.toFixed(0)}m
              {es.rul_confidence < 0.7 && <span style={{ fontSize: 8, opacity: 0.6 }}> ~{(es.rul_confidence * 100).toFixed(0)}%</span>}
            </span>
          )}
          {/* Fleet suppressed */}
          {es.fleet_suppressed && (
            <span
              className="px-1.5 py-0.5 rounded"
              style={{
                fontFamily: MONO, fontSize: 9, fontWeight: 600,
                backgroundColor: "rgba(139,92,246,0.1)",
                color: "#8b5cf6",
                border: "1px solid rgba(139,92,246,0.25)",
              }}
            >
              FLEET
            </span>
          )}
        </div>
      )}

      {/* Compound signatures */}
      {activeSigs.length > 0 && !stopped && (
        <div className="mb-2">
          {activeSigs.map((sig) => (
            <div
              key={sig.name}
              className="rounded px-2 py-1 mb-1"
              style={{
                fontFamily: MONO, fontSize: 9,
                backgroundColor: "rgba(255,136,68,0.06)",
                borderLeft: "2px solid #ff8844",
                color: "#ff8844",
              }}
            >
              ⚠ {sig.name.toUpperCase().replace(/_/g, " ")} — {sig.description}
            </div>
          ))}
        </div>
      )}

      {/* n8n Decision Banner */}
      {n8nDecision && !stopped && (() => {
        const actionLabel = n8nDecision.action === "maintenance scheduled" ? "MAINTENANCE SCHEDULED"
          : n8nDecision.action === "alerted" ? "ALERTED" : "FALSE ALARM";
        const borderColor = n8nDecision.action === "maintenance scheduled" ? "#ff3355"
          : n8nDecision.action === "alerted" ? "#ffcc00" : "#00ff88";
        const bgColor = n8nDecision.action === "maintenance scheduled" ? "rgba(255,51,85,0.06)"
          : n8nDecision.action === "alerted" ? "rgba(255,204,0,0.06)" : "rgba(0,255,136,0.06)";
        const textColor = borderColor;
        const elapsed = Math.round((Date.now() - n8nDecision.timestamp) / 1000);
        return (
          <div
            className="mb-2 rounded-md px-3 py-2"
            style={{ backgroundColor: bgColor, borderLeft: `3px solid ${borderColor}` }}
          >
            <div className="flex items-center justify-between mb-1.5">
              <span style={{ fontFamily: MONO, fontSize: 10, fontWeight: 700, color: textColor, letterSpacing: 0.5 }}>
                n8n: {actionLabel}
              </span>
              <span style={{ fontFamily: MONO, fontSize: 8, color: "#4a5568" }}>
                {elapsed}s ago
              </span>
            </div>
            {n8nDecision.reasoning.length > 0 && (
              <div style={{ marginTop: 2 }}>
                {n8nDecision.reasoning.map((step, i) => (
                  <div
                    key={i}
                    className="flex items-start gap-1.5"
                    style={{ fontFamily: MONO, fontSize: 9, color: "#94a3b8", marginTop: i > 0 ? 3 : 0 }}
                  >
                    <span style={{ color: textColor, fontWeight: 700, flexShrink: 0 }}>{i + 1}.</span>
                    <span>{step}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        );
      })()}

      {/* Sparkline */}
      <div className="mb-2 rounded p-2" style={{ backgroundColor: "#0a0c10", border: "1px solid #1a1f28" }}>
        <div style={{ fontFamily: MONO, fontSize: 9, color: "#4a5568", fontWeight: 500, marginBottom: 4 }}>
          VIBRATION — LAST 60s
        </div>
        <Sparkline data={sparkData} width={280} height={36} color={sparkColor} />
      </div>

      {/* Timestamp */}
      <div style={{ fontFamily: MONO, fontSize: 10, color: "#4a5568", textAlign: "right" }}>
        {reading ? reading.timestamp.replace("T", " ").slice(0, 19) + " UTC" : "Awaiting data..."}
      </div>
    </div>
  );
}

function MetricCell({ label, value, unit, status, z }: { label: string; value: string; unit: string; status: string; z?: number }) {
  const valueColor = status === "stopped" ? "#444" : status === "fault" ? "#ff3355" : status === "warning" ? "#ffcc00" : "#00ff88";
  const absZ = z != null ? Math.abs(z) : 0;
  const zColor = absZ >= 3.0 ? "#ff3355" : absZ >= 2.0 ? "#ffcc00" : "#2d3748";

  return (
    <div className="rounded p-2" style={{ backgroundColor: "#0a0c10", border: "1px solid #1a1f28" }}>
      <div className="flex items-center justify-between">
        <span style={{ fontFamily: MONO, fontSize: 9, color: "#4a5568", fontWeight: 500, letterSpacing: 0.5 }}>{label}</span>
        {z != null && absZ > 0.5 && (
          <span style={{ fontFamily: MONO, fontSize: 8, color: zColor, fontWeight: 600 }}>
            Z:{z.toFixed(1)}
          </span>
        )}
      </div>
      <div style={{ fontFamily: MONO, fontSize: 18, color: valueColor, fontWeight: 500 }}>
        {value}
        <span style={{ fontSize: 10, color: "#4a5568", marginLeft: 2 }}>{unit}</span>
      </div>
    </div>
  );
}