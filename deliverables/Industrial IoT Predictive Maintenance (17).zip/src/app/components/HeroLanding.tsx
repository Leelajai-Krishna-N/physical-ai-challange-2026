import { useState, useEffect } from "react";

const MONO = "'JetBrains Mono', monospace";
const FONT = "'Inter', sans-serif";

interface HeroLandingProps {
  onEnter: () => void;
}

export function HeroLanding({ onEnter }: HeroLandingProps) {
  const [show, setShow] = useState(false);
  const [quoteShow, setQuoteShow] = useState(false);
  const [btnShow, setBtnShow] = useState(false);

  useEffect(() => {
    const t1 = setTimeout(() => setShow(true), 200);
    const t2 = setTimeout(() => setQuoteShow(true), 1200);
    const t3 = setTimeout(() => setBtnShow(true), 2000);
    return () => { clearTimeout(t1); clearTimeout(t2); clearTimeout(t3); };
  }, []);

  return (
    <div
      className="min-h-screen flex flex-col items-center justify-center"
      style={{ backgroundColor: "#0a0c10" }}
    >
      {/* Subtle grid background */}
      <div
        style={{
          position: "absolute",
          inset: 0,
          backgroundImage:
            "linear-gradient(rgba(0,255,136,0.03) 1px, transparent 1px), linear-gradient(90deg, rgba(0,255,136,0.03) 1px, transparent 1px)",
          backgroundSize: "60px 60px",
          pointerEvents: "none",
        }}
      />

      {/* Glow effect behind logo */}
      <div
        style={{
          position: "absolute",
          width: 300,
          height: 300,
          borderRadius: "50%",
          background: "radial-gradient(circle, rgba(0,255,136,0.06) 0%, transparent 70%)",
          pointerEvents: "none",
        }}
      />

      <div
        style={{
          opacity: show ? 1 : 0,
          transform: show ? "translateY(0)" : "translateY(20px)",
          transition: "opacity 0.8s ease, transform 0.8s ease",
          textAlign: "center",
          position: "relative",
        }}
      >
        {/* Logo mark */}
        <div
          style={{
            width: 72,
            height: 72,
            margin: "0 auto 28px",
            border: "2px solid #00ff88",
            borderRadius: 16,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            backgroundColor: "rgba(0,255,136,0.05)",
            boxShadow: "0 0 40px rgba(0,255,136,0.1), inset 0 0 20px rgba(0,255,136,0.03)",
          }}
        >
          <span style={{ fontSize: 32, color: "#00ff88" }}>&#9881;</span>
        </div>

        {/* KAIROS name */}
        <h1
          style={{
            fontFamily: FONT,
            fontWeight: 700,
            fontSize: 56,
            color: "#e2e8f0",
            letterSpacing: 12,
            margin: 0,
          }}
        >
          KAIROS
        </h1>

        {/* Tagline */}
        <p
          style={{
            fontFamily: MONO,
            fontSize: 13,
            color: "#00ff88",
            letterSpacing: 3,
            marginTop: 16,
            opacity: quoteShow ? 1 : 0,
            transform: quoteShow ? "translateY(0)" : "translateY(10px)",
            transition: "opacity 0.6s ease, transform 0.6s ease",
          }}
        >
          Timing makes the difference
        </p>

        {/* Subtitle */}
        <p
          style={{
            fontFamily: MONO,
            fontSize: 10,
            color: "#4a5568",
            letterSpacing: 2,
            marginTop: 24,
            opacity: quoteShow ? 1 : 0,
            transition: "opacity 0.8s ease 0.3s",
          }}
        >
          SENSOR INTELLIGENCE PLATFORM
        </p>

        {/* Enter button */}
        <button
          onClick={onEnter}
          style={{
            marginTop: 48,
            fontFamily: MONO,
            fontSize: 11,
            fontWeight: 600,
            letterSpacing: 2,
            color: "#0a0c10",
            backgroundColor: "#00ff88",
            border: "none",
            padding: "10px 36px",
            borderRadius: 4,
            cursor: "pointer",
            opacity: btnShow ? 1 : 0,
            transform: btnShow ? "translateY(0)" : "translateY(10px)",
            transition: "opacity 0.5s ease, transform 0.5s ease, background-color 0.2s ease, box-shadow 0.2s ease",
            boxShadow: "0 0 20px rgba(0,255,136,0.2)",
          }}
          onMouseEnter={(e) => {
            (e.currentTarget as HTMLButtonElement).style.boxShadow = "0 0 30px rgba(0,255,136,0.35)";
            (e.currentTarget as HTMLButtonElement).style.backgroundColor = "#33ffaa";
          }}
          onMouseLeave={(e) => {
            (e.currentTarget as HTMLButtonElement).style.boxShadow = "0 0 20px rgba(0,255,136,0.2)";
            (e.currentTarget as HTMLButtonElement).style.backgroundColor = "#00ff88";
          }}
        >
          ENTER DASHBOARD
        </button>
      </div>

      {/* Bottom version */}
      <div
        style={{
          position: "absolute",
          bottom: 32,
          fontFamily: MONO,
          fontSize: 9,
          color: "#2d3748",
          letterSpacing: 1.5,
        }}
      >
        KAIROS v2.0 — PREDICTIVE MAINTENANCE SYSTEM
      </div>
    </div>
  );
}
