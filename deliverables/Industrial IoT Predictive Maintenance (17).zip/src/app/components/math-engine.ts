/**
 * KAIROS Predictive Maintenance — Mathematically Rigorous Math Engine
 *
 * Implements: adaptive baselines, direction-aware z-scores, robust scoring,
 * Theil-Sen slopes, RUL estimation, fleet correlation, compound signatures,
 * and priority queue scoring.
 */

import type { ServerReading, MachineId } from "./simulation";
import { BASELINES } from "./simulation";

// ─── CONSTANTS ───
const EPS = 1e-3;
const BETA = 0.95; // adaptive offset decay
const FAST_WINDOW = 20;
const SHORT_WINDOW = 30;
const LONG_WINDOW = 600;
const FLEET_WINDOW = 60;
const STARTUP_READINGS = 30;

// Metrics definition
export type MetricKey = "temperature" | "vibration" | "current" | "rpm";
const METRIC_KEYS: MetricKey[] = ["temperature", "vibration", "current", "rpm"];

// High-bad = value going UP is bad; Low-bad = value going DOWN is bad
const METRIC_DIRECTION: Record<MetricKey, "high-bad" | "low-bad"> = {
  temperature: "high-bad",
  vibration: "high-bad",
  current: "high-bad",
  rpm: "low-bad",
};

// Machine-specific metric weights
const MACHINE_WEIGHTS: Record<string, Partial<Record<MetricKey, number>>> = {
  CNC_01: { vibration: 0.45, temperature: 0.35, current: 0.20 },
  CNC_02: { temperature: 0.50, current: 0.30, vibration: 0.20 },
  PUMP_03: { rpm: 0.45, vibration: 0.35, current: 0.20 },
  CONVEYOR_04: { vibration: 0.34, temperature: 0.33, current: 0.33 }, // sentinel — equal
};

// ─── UTILITY FUNCTIONS ───

function median(arr: number[]): number {
  if (arr.length === 0) return 0;
  const sorted = [...arr].sort((a, b) => a - b);
  const mid = Math.floor(sorted.length / 2);
  return sorted.length % 2 !== 0 ? sorted[mid] : (sorted[mid - 1] + sorted[mid]) / 2;
}

function mad(arr: number[]): number {
  if (arr.length === 0) return 0;
  const med = median(arr);
  const deviations = arr.map((v) => Math.abs(v - med));
  return median(deviations);
}

function stdDev(arr: number[]): number {
  if (arr.length < 2) return 0;
  const mean = arr.reduce((a, b) => a + b, 0) / arr.length;
  return Math.sqrt(arr.reduce((s, v) => s + (v - mean) ** 2, 0) / arr.length);
}

function percentile(arr: number[], p: number): number {
  if (arr.length === 0) return 0;
  const sorted = [...arr].sort((a, b) => a - b);
  const idx = (p / 100) * (sorted.length - 1);
  const lower = Math.floor(idx);
  const upper = Math.ceil(idx);
  if (lower === upper) return sorted[lower];
  return sorted[lower] + (sorted[upper] - sorted[lower]) * (idx - lower);
}

function clamp(v: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, v));
}

/** Theil-Sen slope estimator — robust linear trend */
function theilSenSlope(values: number[]): number {
  const n = values.length;
  if (n < 2) return 0;
  // Sample pairs to keep O(n) for large windows
  const slopes: number[] = [];
  const step = n > 100 ? Math.ceil(n / 100) : 1;
  for (let i = 0; i < n; i += step) {
    for (let j = i + step; j < n; j += step) {
      const denom = j - i;
      if (denom > 0) slopes.push((values[j] - values[i]) / denom);
    }
  }
  return slopes.length > 0 ? median(slopes) : 0;
}

// Extract a metric value from a reading
function extractMetric(r: ServerReading, m: MetricKey): number {
  switch (m) {
    case "temperature": return r.temperature_C;
    case "vibration": return r.vibration_mm_s;
    case "current": return r.current_A;
    case "rpm": return r.rpm;
  }
}

// ─── PER-MACHINE STATE ───

export interface MetricBaseline {
  center_hist: number;
  scale_hist: number;
  offset: number;
  center_eff: number;
  p99: number;
}

export type HealthStage = "healthy" | "aging" | "degraded" | "critical";
export type OperatingPhase = "startup" | "steady" | "high_load" | "low_load";
export type PowerState = "RUNNING" | "QUEUED_FOR_SHUTDOWN" | "SHUTDOWN";

export type FleetEventType = "ambient-shift" | "power-quality-load-event" | "unknown-fleet-event" | null;

export interface MetricScore {
  z: number;
  short_score: number;
  long_score: number;
  persistence_short: number;
  persistence_long: number;
  slope: number;
  rul_minutes: number;
}

export interface CompoundSignature {
  name: string;
  active: boolean;
  description: string;
}

export interface MachineState {
  machine_id: string;
  // Baselines
  baselines: Record<MetricKey, MetricBaseline>;
  // Current scores
  metric_scores: Record<MetricKey, MetricScore>;
  // Composite
  risk_score: number;
  remaining_life_minutes: number;
  rul_confidence: number;
  health_stage: HealthStage;
  operating_phase: OperatingPhase;
  power_state: PowerState;
  // Fleet
  fleet_event_type: FleetEventType;
  fleet_suppressed: boolean;
  // Signatures
  compound_signatures: CompoundSignature[];
  // Priority
  priority_score_math: number;
  priority_rank: number;
  is_top_ticket: boolean;
  // Counters
  readings_since_connect: number;
  // Pattern
  pattern_key: string;
}

export interface FleetContext {
  event_type: FleetEventType;
  affected_metric: MetricKey | null;
  affected_machines: string[];
  consecutive_seconds: number;
}

// ─── ENGINE CLASS ───

export class PredictiveEngine {
  // Per-machine windows
  private fastWindows: Record<string, ServerReading[]> = {};
  private shortWindows: Record<string, ServerReading[]> = {};
  private longWindows: Record<string, ServerReading[]> = {};
  // Per-machine z-score histories per metric (for persistence/slope)
  private zHistoryShort: Record<string, Record<MetricKey, number[]>> = {};
  private zHistoryLong: Record<string, Record<MetricKey, number[]>> = {};
  private valueHistoryLong: Record<string, Record<MetricKey, number[]>> = {};
  // Per-machine adaptive state
  private offsets: Record<string, Record<MetricKey, number>> = {};
  private readingCounts: Record<string, number> = {};
  // Per-machine baselines (computed from rolling window)
  private baselineCache: Record<string, Record<MetricKey, MetricBaseline>> = {};
  // Fleet z-score history per metric (last 60 readings per machine)
  private fleetZHistory: Record<string, Record<MetricKey, number[]>> = {};
  // Fleet consecutive counter per metric
  private fleetConsecutive: Record<MetricKey, number> = {
    temperature: 0, vibration: 0, current: 0, rpm: 0,
  };
  // Fleet context
  public fleetContext: FleetContext = {
    event_type: null,
    affected_metric: null,
    affected_machines: [],
    consecutive_seconds: 0,
  };
  // Machine states
  public machineStates: Record<string, MachineState> = {};
  // Power state overrides
  private powerOverrides: Record<string, PowerState> = {};

  constructor(private machines: readonly string[]) {
    for (const m of machines) {
      this.fastWindows[m] = [];
      this.shortWindows[m] = [];
      this.longWindows[m] = [];
      this.zHistoryShort[m] = { temperature: [], vibration: [], current: [], rpm: [] };
      this.zHistoryLong[m] = { temperature: [], vibration: [], current: [], rpm: [] };
      this.valueHistoryLong[m] = { temperature: [], vibration: [], current: [], rpm: [] };
      this.offsets[m] = { temperature: 0, vibration: 0, current: 0, rpm: 0 };
      this.readingCounts[m] = 0;
      this.fleetZHistory[m] = { temperature: [], vibration: [], current: [], rpm: [] };
      this.initMachineState(m);
    }
  }

  private initMachineState(m: string) {
    const b = BASELINES[m as MachineId] || { temp: 50, vib: 1.5, rpm: 1500, current: 12 };
    const makeBaseline = (center: number): MetricBaseline => ({
      center_hist: center,
      scale_hist: Math.max(0.02 * Math.abs(center), EPS),
      offset: 0,
      center_eff: center,
      p99: center * 1.1,
    });

    this.baselineCache[m] = {
      temperature: makeBaseline(b.temp),
      vibration: makeBaseline(b.vib),
      current: makeBaseline(b.current),
      rpm: makeBaseline(b.rpm),
    };

    this.machineStates[m] = {
      machine_id: m,
      baselines: this.baselineCache[m],
      metric_scores: {
        temperature: { z: 0, short_score: 0, long_score: 0, persistence_short: 0, persistence_long: 0, slope: 0, rul_minutes: Infinity },
        vibration: { z: 0, short_score: 0, long_score: 0, persistence_short: 0, persistence_long: 0, slope: 0, rul_minutes: Infinity },
        current: { z: 0, short_score: 0, long_score: 0, persistence_short: 0, persistence_long: 0, slope: 0, rul_minutes: Infinity },
        rpm: { z: 0, short_score: 0, long_score: 0, persistence_short: 0, persistence_long: 0, slope: 0, rul_minutes: Infinity },
      },
      risk_score: 0,
      remaining_life_minutes: Infinity,
      rul_confidence: 0,
      health_stage: "healthy",
      operating_phase: "startup",
      power_state: "RUNNING",
      fleet_event_type: null,
      fleet_suppressed: false,
      compound_signatures: [],
      priority_score_math: 0,
      priority_rank: 0,
      is_top_ticket: false,
      readings_since_connect: 0,
      pattern_key: "normal",
    };
  }

  /** Reset a machine (e.g. after resume) */
  resetMachine(m: string) {
    this.fastWindows[m] = [];
    this.shortWindows[m] = [];
    this.longWindows[m] = [];
    this.zHistoryShort[m] = { temperature: [], vibration: [], current: [], rpm: [] };
    this.zHistoryLong[m] = { temperature: [], vibration: [], current: [], rpm: [] };
    this.valueHistoryLong[m] = { temperature: [], vibration: [], current: [], rpm: [] };
    this.offsets[m] = { temperature: 0, vibration: 0, current: 0, rpm: 0 };
    this.readingCounts[m] = 0;
    this.fleetZHistory[m] = { temperature: [], vibration: [], current: [], rpm: [] };
    this.powerOverrides[m] = "RUNNING";
    this.initMachineState(m);
  }

  setPowerState(m: string, state: PowerState) {
    this.powerOverrides[m] = state;
    if (this.machineStates[m]) {
      this.machineStates[m].power_state = state;
    }
  }

  /**
   * Process a single reading — this is the main entry point.
   * Returns the updated MachineState.
   */
  processReading(machineId: string, reading: ServerReading): MachineState {
    // Push into windows
    this.fastWindows[machineId].push(reading);
    this.shortWindows[machineId].push(reading);
    this.longWindows[machineId].push(reading);
    if (this.fastWindows[machineId].length > FAST_WINDOW) this.fastWindows[machineId].shift();
    if (this.shortWindows[machineId].length > SHORT_WINDOW) this.shortWindows[machineId].shift();
    if (this.longWindows[machineId].length > LONG_WINDOW) this.longWindows[machineId].shift();

    this.readingCounts[machineId] = (this.readingCounts[machineId] || 0) + 1;
    const readCount = this.readingCounts[machineId];

    // 1. Update adaptive baselines
    this.updateBaselines(machineId, reading);

    // 2. Compute direction-aware z-scores
    const zScores = this.computeZScores(machineId, reading);

    // 3. Update z-score histories
    for (const m of METRIC_KEYS) {
      this.zHistoryShort[machineId][m].push(zScores[m]);
      this.zHistoryLong[machineId][m].push(zScores[m]);
      this.valueHistoryLong[machineId][m].push(extractMetric(reading, m));
      if (this.zHistoryShort[machineId][m].length > SHORT_WINDOW) this.zHistoryShort[machineId][m].shift();
      if (this.zHistoryLong[machineId][m].length > LONG_WINDOW) this.zHistoryLong[machineId][m].shift();
      if (this.valueHistoryLong[machineId][m].length > LONG_WINDOW) this.valueHistoryLong[machineId][m].shift();

      // Fleet z history
      this.fleetZHistory[machineId][m].push(zScores[m]);
      if (this.fleetZHistory[machineId][m].length > FLEET_WINDOW) this.fleetZHistory[machineId][m].shift();
    }

    // 4. Compute scores per metric
    const metricScores: Record<MetricKey, MetricScore> = {} as any;
    for (const m of METRIC_KEYS) {
      metricScores[m] = this.computeMetricScore(machineId, m, zScores[m]);
    }

    // 5. Fleet correlation
    this.updateFleetCorrelation();

    // 6. Operating phase
    const operatingPhase = this.determineOperatingPhase(machineId, reading, readCount);

    // 7. Compound signatures
    const signatures = this.detectCompoundSignatures(machineId, metricScores);

    // 8. Risk score (weighted composite)
    const weights = MACHINE_WEIGHTS[machineId] || MACHINE_WEIGHTS.CNC_01;
    let riskScore = 0;
    for (const m of METRIC_KEYS) {
      const w = weights[m] || 0;
      // Blend short and long scores
      const blended = 0.6 * metricScores[m].short_score + 0.4 * metricScores[m].long_score;
      riskScore += w * blended;
    }
    // Boost for active compound signatures
    const activeSignatures = signatures.filter((s) => s.active);
    if (activeSignatures.length > 0) {
      riskScore = Math.min(100, riskScore * 1.15 + 5);
    }
    riskScore = clamp(riskScore, 0, 100);

    // 9. RUL
    const { rul, confidence } = this.computeRUL(machineId, metricScores);

    // 10. Health stage
    const healthStage = this.determineHealthStage(riskScore);

    // 11. Fleet suppression
    const fleetSuppressed = this.fleetContext.event_type !== null &&
      this.fleetContext.affected_machines.includes(machineId);

    // 12. Pattern key
    const patternKey = this.determinePatternKey(machineId, activeSignatures, metricScores);

    // 13. Power state
    const powerState = this.powerOverrides[machineId] || "RUNNING";

    // Build state
    const state: MachineState = {
      machine_id: machineId,
      baselines: this.baselineCache[machineId],
      metric_scores: metricScores,
      risk_score: Math.round(riskScore * 10) / 10,
      remaining_life_minutes: rul,
      rul_confidence: confidence,
      health_stage: healthStage,
      operating_phase: operatingPhase,
      power_state: powerState,
      fleet_event_type: fleetSuppressed ? this.fleetContext.event_type : null,
      fleet_suppressed: fleetSuppressed,
      compound_signatures: signatures,
      priority_score_math: 0, // computed in batch after all machines
      priority_rank: 0,
      is_top_ticket: false,
      readings_since_connect: readCount,
      pattern_key: patternKey,
    };

    this.machineStates[machineId] = state;
    return state;
  }

  /** Update adaptive baselines from rolling window */
  private updateBaselines(machineId: string, reading: ServerReading) {
    const fast = this.fastWindows[machineId];
    if (fast.length < 5) return;

    const isHealthy = reading.status === "running";

    for (const m of METRIC_KEYS) {
      const vals = fast.map((r) => extractMetric(r, m));
      const centerHist = median(vals);
      const madVal = mad(vals);
      const stdVal = stdDev(vals);
      const scaleHist = Math.max(1.4826 * madVal, stdVal, 0.02 * Math.abs(centerHist), EPS);

      // Adaptive offset — only update during healthy windows and no fleet event
      let offset = this.offsets[machineId][m];
      if (isHealthy && this.fleetContext.event_type === null) {
        const currentVal = extractMetric(reading, m);
        offset = BETA * offset + (1 - BETA) * (currentVal - centerHist);
        this.offsets[machineId][m] = offset;
      }

      const centerEff = centerHist + offset;

      // P99 from long window if available, else from fast
      const longVals = this.valueHistoryLong[machineId][m];
      const p99 = longVals.length >= 20 ? percentile(longVals, 99) : percentile(vals, 99);

      this.baselineCache[machineId][m] = {
        center_hist: centerHist,
        scale_hist: scaleHist,
        offset,
        center_eff: centerEff,
        p99,
      };
    }
  }

  /** Direction-aware z-scores */
  private computeZScores(machineId: string, reading: ServerReading): Record<MetricKey, number> {
    const result: Record<MetricKey, number> = {} as any;
    const bl = this.baselineCache[machineId];

    for (const m of METRIC_KEYS) {
      const x = extractMetric(reading, m);
      const { center_eff, scale_hist } = bl[m];
      if (METRIC_DIRECTION[m] === "high-bad") {
        result[m] = (x - center_eff) / scale_hist;
      } else {
        // low-bad (rpm): lower is worse
        result[m] = (center_eff - x) / scale_hist;
      }
    }
    return result;
  }

  /** Compute per-metric score (short + long + persistence + slope + RUL) */
  private computeMetricScore(machineId: string, metric: MetricKey, currentZ: number): MetricScore {
    const shortZ = this.zHistoryShort[machineId][metric];
    const longZ = this.zHistoryLong[machineId][metric];
    const longVals = this.valueHistoryLong[machineId][metric];
    const bl = this.baselineCache[machineId][metric];

    // Persistence = fraction of z > 2.0
    const persistenceShort = shortZ.length > 0
      ? shortZ.filter((z) => z > 2.0).length / shortZ.length : 0;
    const persistenceLong = longZ.length > 0
      ? longZ.filter((z) => z > 2.0).length / longZ.length : 0;

    // Short score (from positive z values in short window)
    const positiveShortZ = shortZ.filter((z) => z > 0);
    const shortScoreRaw = positiveShortZ.length > 0
      ? 0.5 * median(positiveShortZ) + 0.3 * Math.max(...positiveShortZ) + 0.2 * (4 * persistenceShort)
      : 0;
    // Scale to 0-100: raw score of ~5 maps to ~100
    const shortScore = clamp(shortScoreRaw * 20, 0, 100);

    // Theil-Sen slope over long window
    const slope = longVals.length >= 10 ? theilSenSlope(longVals) : 0;

    // Long score
    const positiveLongZ = longZ.filter((z) => z > 0);
    const normalizedTrend = bl.scale_hist > EPS
      ? Math.max(0, (METRIC_DIRECTION[metric] === "high-bad" ? slope : -slope) / bl.scale_hist)
      : 0;
    const longScoreRaw = positiveLongZ.length > 0
      ? 0.5 * median(positiveLongZ) + 0.25 * (4 * persistenceLong) + 0.25 * normalizedTrend
      : 0;
    const longScore = clamp(longScoreRaw * 20, 0, 100);

    // Metric RUL
    let rulMinutes = Infinity;
    const currentVal = longVals.length > 0 ? longVals[longVals.length - 1] : 0;
    if (METRIC_DIRECTION[metric] === "high-bad") {
      const limit = Math.max(bl.p99, bl.center_eff + 3.5 * bl.scale_hist);
      if (slope > EPS) {
        const secondsToLimit = (limit - currentVal) / slope;
        if (secondsToLimit > 0) rulMinutes = secondsToLimit / 60;
      }
    } else {
      // low-bad (rpm)
      const limit = bl.center_eff - 3.5 * bl.scale_hist;
      if (slope < -EPS) {
        const secondsToLimit = (currentVal - limit) / (-slope);
        if (secondsToLimit > 0) rulMinutes = secondsToLimit / 60;
      }
    }

    return {
      z: Math.round(currentZ * 1000) / 1000,
      short_score: Math.round(shortScore * 10) / 10,
      long_score: Math.round(longScore * 10) / 10,
      persistence_short: Math.round(persistenceShort * 1000) / 1000,
      persistence_long: Math.round(persistenceLong * 1000) / 1000,
      slope: Math.round(slope * 10000) / 10000,
      rul_minutes: rulMinutes === Infinity ? Infinity : Math.round(rulMinutes * 10) / 10,
    };
  }

  /** Fleet correlation detection */
  private updateFleetCorrelation() {
    for (const metric of METRIC_KEYS) {
      // Count machines with same-sign |z| >= 2.5 in their latest reading
      let positiveCount = 0;
      let negativeCount = 0;
      const affectedMachines: string[] = [];

      for (const m of this.machines) {
        const hist = this.fleetZHistory[m]?.[metric];
        if (!hist || hist.length === 0) continue;
        const latestZ = hist[hist.length - 1];
        if (latestZ >= 2.5) {
          positiveCount++;
          affectedMachines.push(m);
        } else if (latestZ <= -2.5) {
          negativeCount++;
          affectedMachines.push(m);
        }
      }

      const triggered = Math.max(positiveCount, negativeCount) >= 3;
      if (triggered) {
        this.fleetConsecutive[metric]++;
      } else {
        this.fleetConsecutive[metric] = 0;
      }

      // Fleet event requires 3 consecutive seconds
      if (this.fleetConsecutive[metric] >= 3) {
        let eventType: FleetEventType;
        if (metric === "temperature") {
          eventType = "ambient-shift";
        } else if (metric === "current" || metric === "rpm") {
          eventType = "power-quality-load-event";
        } else {
          eventType = "unknown-fleet-event";
        }
        this.fleetContext = {
          event_type: eventType,
          affected_metric: metric,
          affected_machines: affectedMachines,
          consecutive_seconds: this.fleetConsecutive[metric],
        };
        return; // First detected fleet event wins
      }
    }

    // No fleet event active — check if we should clear
    const anyActive = METRIC_KEYS.some((m) => this.fleetConsecutive[m] >= 3);
    if (!anyActive) {
      this.fleetContext = { event_type: null, affected_metric: null, affected_machines: [], consecutive_seconds: 0 };
    }
  }

  /** Determine operating phase */
  private determineOperatingPhase(machineId: string, reading: ServerReading, readCount: number): OperatingPhase {
    if (readCount <= STARTUP_READINGS) return "startup";

    const b = BASELINES[machineId as MachineId];
    if (!b) return "steady";

    const currentRatio = reading.current_A / b.current;
    if (currentRatio > 1.15) return "high_load";
    if (currentRatio < 0.85) return "low_load";
    return "steady";
  }

  /** Detect compound signatures */
  private detectCompoundSignatures(machineId: string, scores: Record<MetricKey, MetricScore>): CompoundSignature[] {
    const sigs: CompoundSignature[] = [];

    if (machineId === "CNC_01") {
      // Bearing wear: vibration + temperature + current all elevated
      const active = scores.vibration.z > 2.0 && scores.temperature.z > 1.5 && scores.current.z > 1.5;
      sigs.push({
        name: "bearing_wear",
        active,
        description: "Vibration + temperature + current rising together — consistent with bearing wear",
      });
    }

    if (machineId === "CNC_02") {
      // Thermal runaway: temperature + current elevated
      const active = scores.temperature.z > 2.0 && scores.current.z > 1.5;
      sigs.push({
        name: "thermal_runaway",
        active,
        description: "Temperature + current elevation — consistent with thermal runaway risk",
      });
    }

    if (machineId === "PUMP_03") {
      // Cavitation/clog: vibration bursts + rpm drop + current rise
      const active = scores.vibration.z > 2.0 && scores.rpm.z > 1.5 && scores.current.z > 1.5;
      sigs.push({
        name: "cavitation_clog",
        active,
        description: "Vibration bursts + RPM drop + current rise — consistent with cavitation or blockage",
      });
    }

    if (machineId === "CONVEYOR_04") {
      sigs.push({ name: "sentinel", active: false, description: "Sentinel machine — reference only" });
    }

    return sigs;
  }

  /** Compute RUL from all metric RULs */
  private computeRUL(machineId: string, scores: Record<MetricKey, MetricScore>): { rul: number; confidence: number } {
    const weights = MACHINE_WEIGHTS[machineId] || {};
    let minRUL = Infinity;
    let totalConfidence = 1.0;

    for (const m of METRIC_KEYS) {
      const w = weights[m] || 0;
      if (w === 0) continue;
      const metricRUL = scores[m].rul_minutes;
      if (metricRUL < minRUL) minRUL = metricRUL;
    }

    // Confidence decreases if:
    // - slope is unstable (small long window)
    const longLen = this.zHistoryLong[machineId]?.temperature?.length || 0;
    if (longLen < 60) totalConfidence *= 0.5;
    else if (longLen < 200) totalConfidence *= 0.8;

    // - fleet event active
    if (this.fleetContext.event_type !== null) totalConfidence *= 0.6;

    // - startup phase
    const readCount = this.readingCounts[machineId] || 0;
    if (readCount <= STARTUP_READINGS) totalConfidence *= 0.3;

    // - evidence is weak (low risk)
    const riskProxy = Object.values(scores).reduce((max, s) => Math.max(max, s.short_score), 0);
    if (riskProxy < 20) totalConfidence *= 0.5;

    return {
      rul: minRUL === Infinity ? Infinity : Math.round(minRUL * 10) / 10,
      confidence: Math.round(clamp(totalConfidence, 0, 1) * 100) / 100,
    };
  }

  /** Determine health stage from risk score */
  private determineHealthStage(risk: number): HealthStage {
    if (risk >= 75) return "critical";
    if (risk >= 50) return "degraded";
    if (risk >= 25) return "aging";
    return "healthy";
  }

  /** Pattern key for fingerprinting */
  private determinePatternKey(machineId: string, activeSigs: CompoundSignature[], scores: Record<MetricKey, MetricScore>): string {
    if (activeSigs.length > 0) return activeSigs[0].name;
    const highMetrics = METRIC_KEYS.filter((m) => scores[m].z > 3.0);
    if (highMetrics.length > 1) return `multi_metric_${highMetrics.join("_")}`;
    if (highMetrics.length === 1) return `${highMetrics[0]}_anomaly`;
    return "normal";
  }

  /**
   * Compute priority queue across all machines.
   * Call AFTER processing all readings for this tick.
   */
  computePriorityQueue(): MachineState[] {
    const candidates: MachineState[] = [];

    for (const m of this.machines) {
      const state = this.machineStates[m];
      if (!state || state.power_state === "SHUTDOWN") continue;
      // CONVEYOR_04 is sentinel — never auto-schedule
      if (m === "CONVEYOR_04") continue;

      const riskNorm = state.risk_score / 100;
      const rulUrgency = clamp((240 - Math.min(state.remaining_life_minutes, 240)) / 240, 0, 1);
      // Use max persistence_long across metrics
      const persistenceNorm = Math.max(
        ...METRIC_KEYS.map((mk) => state.metric_scores[mk].persistence_long)
      );
      const hardFaultBonus = state.health_stage === "critical" ? 1 : 0;
      const fleetIsolation = state.fleet_suppressed ? 0.4 : 1.0;

      const priorityScore = 100 * (
        0.35 * riskNorm +
        0.25 * rulUrgency +
        0.15 * persistenceNorm +
        0.15 * hardFaultBonus +
        0.10 * fleetIsolation
      );

      state.priority_score_math = Math.round(priorityScore * 10) / 10;
      candidates.push(state);
    }

    // Sort by priority descending
    candidates.sort((a, b) => b.priority_score_math - a.priority_score_math);

    // Assign ranks
    candidates.forEach((c, i) => {
      c.priority_rank = i + 1;
      c.is_top_ticket = i === 0 && c.risk_score >= 25; // only if actually at risk
    });

    return candidates;
  }

  /**
   * Build a compact LLM evidence packet for a machine.
   * The LLM must NOT receive raw telemetry.
   */
  buildEvidencePacket(machineId: string, reading: ServerReading): Record<string, any> {
    const state = this.machineStates[machineId];
    if (!state) return {};

    // Sentinel comparison
    const sentinelState = this.machineStates["CONVEYOR_04"];
    const sentinelSimilar = sentinelState
      ? METRIC_KEYS.some((m) => {
          const mz = Math.abs(state.metric_scores[m].z);
          const sz = Math.abs(sentinelState.metric_scores[m].z);
          return mz > 2.0 && sz > 2.0 && Math.sign(state.metric_scores[m].z) === Math.sign(sentinelState.metric_scores[m].z);
        })
      : false;

    // Current queue snapshot
    const queueSnapshot = this.machines
      .filter((m) => m !== "CONVEYOR_04" && this.machineStates[m]?.risk_score >= 25)
      .map((m) => ({
        machine_id: m,
        risk_score: this.machineStates[m].risk_score,
        priority_rank: this.machineStates[m].priority_rank,
        health_stage: this.machineStates[m].health_stage,
      }));

    return {
      machine_id: machineId,
      timestamp: reading.timestamp,
      operating_phase: state.operating_phase,
      fleet_context: this.fleetContext,
      current_metrics: {
        temperature_C: reading.temperature_C,
        vibration_mm_s: reading.vibration_mm_s,
        current_A: reading.current_A,
        rpm: reading.rpm,
      },
      top_z_scores: Object.fromEntries(METRIC_KEYS.map((m) => [m, state.metric_scores[m].z])),
      short_scores: Object.fromEntries(METRIC_KEYS.map((m) => [m, state.metric_scores[m].short_score])),
      long_scores: Object.fromEntries(METRIC_KEYS.map((m) => [m, state.metric_scores[m].long_score])),
      theil_sen_slopes: Object.fromEntries(METRIC_KEYS.map((m) => [m, state.metric_scores[m].slope])),
      persistence_values: Object.fromEntries(METRIC_KEYS.map((m) => [m, {
        short: state.metric_scores[m].persistence_short,
        long: state.metric_scores[m].persistence_long,
      }])),
      compound_signatures: state.compound_signatures.filter((s) => s.active).map((s) => s.name),
      remaining_life_minutes: state.remaining_life_minutes,
      rul_confidence: state.rul_confidence,
      health_stage: state.health_stage,
      risk_score: state.risk_score,
      sentinel_moved_similarly: sentinelSimilar,
      math_pre_priority_score: state.priority_score_math,
      queue_snapshot: queueSnapshot,
    };
  }

  /**
   * Should we wake the LLM for this machine?
   * LLM wake policy: risk >= 60 OR RUL < 240 OR hard fault OR fleet event OR >1 machine in anomaly
   */
  shouldWakeLLM(machineId: string): boolean {
    const state = this.machineStates[machineId];
    if (!state) return false;
    if (state.operating_phase === "startup") return false; // suppress during startup

    if (state.risk_score >= 60) return true;
    if (state.remaining_life_minutes < 240) return true;
    if (state.health_stage === "critical") return true;
    if (this.fleetContext.event_type !== null) return true;

    // More than one machine in active anomaly
    const anomalyCount = this.machines.filter((m) =>
      this.machineStates[m]?.risk_score >= 25
    ).length;
    if (anomalyCount > 1) return true;

    return false;
  }

  /** Get simple z-scores compatible with existing App.tsx interface */
  getSimpleZScores(machineId: string): Record<string, number> {
    const state = this.machineStates[machineId];
    if (!state) return { temperature: 0, vibration: 0, current: 0, rpm: 0 };
    return {
      temperature: state.metric_scores.temperature.z,
      vibration: state.metric_scores.vibration.z,
      current: state.metric_scores.current.z,
      rpm: state.metric_scores.rpm.z,
    };
  }
}
