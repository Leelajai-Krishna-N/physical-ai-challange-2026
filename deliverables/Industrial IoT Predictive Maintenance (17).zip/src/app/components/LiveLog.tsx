import { useEffect, useRef } from "react";

const MONO = "'JetBrains Mono', monospace";
const FONT = "'Inter', sans-serif";

export interface LogEntry {
  id: string;
  timestamp: number;
  machineId: string;
  level: "info" | "warning" | "critical" | "success" | "system";
  message: string;
}

const levelConfig = {
  info: { color: "#4a8fe8", tag: "INFO", tagBg: "rgba(74,143,232,0.12)", tagBorder: "rgba(74,143,232,0.3)" },
  warning: { color: "#ffcc00", tag: "HIGH", tagBg: "rgba(255,204,0,0.12)", tagBorder: "rgba(255,204,0,0.3)" },
  critical: { color: "#ff3355", tag: "CRITICAL", tagBg: "rgba(255,51,85,0.12)", tagBorder: "rgba(255,51,85,0.3)" },
  success: { color: "#00ff88", tag: "OK", tagBg: "rgba(0,255,136,0.12)", tagBorder: "rgba(0,255,136,0.3)" },
  system: { color: "#8b5cf6", tag: "SYSTEM", tagBg: "rgba(139,92,246,0.12)", tagBorder: "rgba(139,92,246,0.3)" },
};

function formatTime(ts: number) {
  const d = new Date(ts);
  const h = d.getHours().toString().padStart(2, "0");
  const m = d.getMinutes().toString().padStart(2, "0");
  const s = d.getSeconds().toString().padStart(2, "0");
  return `${h}:${m}:${s}`;
}

interface LiveLogProps {
  entries: LogEntry[];
}

export function LiveLog({ entries }: LiveLogProps) {
  const scrollRef = useRef<HTMLDivElement>(null);
  const autoScrollRef = useRef(true);

  useEffect(() => {
    const el = scrollRef.current;
    if (el && autoScrollRef.current) {
      el.scrollTop = el.scrollHeight;
    }
  }, [entries]);

  const handleScroll = () => {
    const el = scrollRef.current;
    if (!el) return;
    const atBottom = el.scrollHeight - el.scrollTop - el.clientHeight < 40;
    autoScrollRef.current = atBottom;
  };

  return (
    <div
      className="rounded-md mt-4"
      style={{ backgroundColor: "#0d0f14", border: "1px solid #1a1f28" }}
    >
      {/* Header bar */}
      <div
        className="flex items-center justify-between px-4 py-2.5"
        style={{ borderBottom: "1px solid #1a1f28", backgroundColor: "#111418" }}
      >
        <div className="flex items-center gap-2.5">
          <div
            style={{
              width: 6,
              height: 6,
              borderRadius: "50%",
              backgroundColor: entries.length > 0 ? "#00ff88" : "#4a5568",
              boxShadow: entries.length > 0 ? "0 0 8px rgba(0,255,136,0.5)" : "none",
              animation: entries.length > 0 ? "pulse 2s infinite" : undefined,
            }}
          />
          <span style={{ fontFamily: FONT, fontWeight: 600, color: "#e2e8f0", fontSize: 13, letterSpacing: 0.5 }}>
            LIVE ACTIVITY LOG
          </span>
          {entries.length > 0 && (
            <span
              className="px-1.5 py-0.5 rounded"
              style={{
                fontFamily: MONO,
                fontSize: 9,
                fontWeight: 500,
                backgroundColor: "rgba(0,255,136,0.08)",
                color: "#4a5568",
                border: "1px solid #1e2530",
              }}
            >
              {entries.length} events
            </span>
          )}
        </div>
        <span style={{ fontFamily: MONO, fontSize: 9, color: "#4a5568" }}>
          AUTO-SCROLL {autoScrollRef.current ? "ON" : "OFF"}
        </span>
      </div>

      {/* Log entries */}
      <div
        ref={scrollRef}
        onScroll={handleScroll}
        className="overflow-y-auto"
        style={{
          maxHeight: 280,
          scrollbarWidth: "thin",
          scrollbarColor: "#1e2530 transparent",
        }}
      >
        {entries.length === 0 ? (
          <div
            className="py-10 text-center"
            style={{ fontFamily: MONO, fontSize: 11, color: "#2d3748" }}
          >
            Waiting for SSE stream data...
          </div>
        ) : (
          entries.map((entry) => {
            const cfg = levelConfig[entry.level];
            return (
              <div
                key={entry.id}
                className="flex items-start gap-0 px-4 py-1.5"
                style={{
                  borderBottom: "1px solid #12151b",
                  backgroundColor: entry.level === "critical" ? "rgba(255,51,85,0.03)" : "transparent",
                  transition: "background-color 0.15s",
                }}
                onMouseEnter={(e) => { (e.currentTarget as HTMLDivElement).style.backgroundColor = "rgba(255,255,255,0.02)"; }}
                onMouseLeave={(e) => { (e.currentTarget as HTMLDivElement).style.backgroundColor = entry.level === "critical" ? "rgba(255,51,85,0.03)" : "transparent"; }}
              >
                {/* Machine ID badge */}
                <span
                  className="shrink-0 px-1.5 py-px rounded mr-3"
                  style={{
                    fontFamily: MONO,
                    fontSize: 10,
                    fontWeight: 600,
                    backgroundColor: `${cfg.color}15`,
                    color: cfg.color,
                    border: `1px solid ${cfg.color}30`,
                    letterSpacing: 0.3,
                    marginTop: 1,
                    minWidth: 72,
                    textAlign: "center",
                  }}
                >
                  {entry.machineId}
                </span>

                {/* Severity tag */}
                <span
                  className="shrink-0 mr-2"
                  style={{
                    fontFamily: MONO,
                    fontSize: 9,
                    fontWeight: 600,
                    color: cfg.color,
                    letterSpacing: 0.5,
                    marginTop: 2,
                    minWidth: 62,
                  }}
                >
                  [{cfg.tag}]
                </span>

                {/* Message */}
                <span
                  className="flex-1 min-w-0"
                  style={{
                    fontFamily: MONO,
                    fontSize: 11,
                    color: "#94a3b8",
                    lineHeight: 1.55,
                    wordBreak: "break-word",
                  }}
                >
                  {entry.message}
                </span>

                {/* Timestamp */}
                <span
                  className="shrink-0 ml-4"
                  style={{
                    fontFamily: MONO,
                    fontSize: 10,
                    color: "#2d3748",
                    marginTop: 2,
                    whiteSpace: "nowrap",
                  }}
                >
                  {formatTime(entry.timestamp)}
                </span>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}
