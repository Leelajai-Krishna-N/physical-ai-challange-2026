// Types and constants matching server.js

export const SERVER_URL = "http://localhost:3000";

export const MACHINES = ["CNC_01", "CNC_02", "PUMP_03", "CONVEYOR_04"] as const;
export type MachineId = (typeof MACHINES)[number];

export const MACHINE_LABELS: Record<MachineId, string> = {
  CNC_01: "CNC Mill #01",
  CNC_02: "CNC Lathe #02",
  PUMP_03: "Hydraulic Pump #03",
  CONVEYOR_04: "Belt Conveyor #04",
};

// Baselines from generate-history.js
export const BASELINES: Record<MachineId, { temp: number; vib: number; rpm: number; current: number }> = {
  CNC_01:      { temp: 72,  vib: 1.8, rpm: 1480, current: 12.5 },
  CNC_02:      { temp: 68,  vib: 1.5, rpm: 1490, current: 11.8 },
  PUMP_03:     { temp: 55,  vib: 2.2, rpm: 2950, current: 18.0 },
  CONVEYOR_04: { temp: 45,  vib: 0.9, rpm:  720, current:  8.5 },
};

export interface ServerReading {
  machine_id: string;
  timestamp: string;
  temperature_C: number;
  vibration_mm_s: number;
  rpm: number;
  current_A: number;
  status: "running" | "warning" | "fault";
}

export interface Alert {
  id: string;
  machineId: string;
  reason: string;
  timestamp: number;
  severity: "warning" | "critical";
}

// Z-score anomaly detection on a sliding window
export function computeZScores(window: ServerReading[]): Record<string, number> {
  if (window.length < 5) return { temperature: 0, vibration: 0, rpm: 0, current: 0 };

  const latest = window[window.length - 1];
  const keys: { key: string; accessor: (r: ServerReading) => number }[] = [
    { key: "temperature", accessor: (r) => r.temperature_C },
    { key: "vibration", accessor: (r) => r.vibration_mm_s },
    { key: "rpm", accessor: (r) => r.rpm },
    { key: "current", accessor: (r) => r.current_A },
  ];

  const zScores: Record<string, number> = {};
  for (const { key, accessor } of keys) {
    const vals = window.map(accessor);
    const mean = vals.reduce((a, b) => a + b, 0) / vals.length;
    const std = Math.sqrt(vals.reduce((a, v) => a + (v - mean) ** 2, 0) / vals.length) || 1;
    zScores[key] = (accessor(latest) - mean) / std;
  }
  return zScores;
}
