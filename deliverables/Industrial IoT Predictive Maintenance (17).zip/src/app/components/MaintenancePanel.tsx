const FONT = "'Inter', sans-serif";
const MONO = "'JetBrains Mono', monospace";

export interface MaintenanceSchedule {
  id: string;
  machine_id: string;
  reason: string;
  status: "pending_confirmation" | "confirmed" | "webhook_sent";
  created_at: string;
  confirmed_at: string | null;
}

interface MaintenancePanelProps {
  schedules: MaintenanceSchedule[];
  stoppedMachines: Record<string, any>;
  onResume: (machineId: string) => void;
}

function formatTime(ts: string) {
  const d = new Date(ts);
  const h12 = (d.getHours() % 12 || 12).toString();
  const m = d.getMinutes().toString().padStart(2, "0");
  const s = d.getSeconds().toString().padStart(2, "0");
  const ampm = d.getHours() >= 12 ? "PM" : "AM";
  return `${h12}:${m}:${s} ${ampm}`;
}

export function MaintenancePanel({ schedules, stoppedMachines, onResume }: MaintenancePanelProps) {
  // Only show panel when there are actual schedules (created after n8n confirmation)
  if (schedules.length === 0) return null;

  return (
    <div
      className="rounded-md p-4 mt-4"
      style={{ backgroundColor: "#111418", border: "1px solid #1a1f28" }}
    >
      <div className="flex items-center gap-2.5 mb-4">
        <div
          style={{
            width: 6,
            height: 6,
            borderRadius: "50%",
            backgroundColor: "#ffcc00",
            boxShadow: "0 0 8px rgba(255,204,0,0.4)",
          }}
        />
        <span style={{ fontFamily: FONT, fontWeight: 600, color: "#e2e8f0", fontSize: 14, letterSpacing: 0.5 }}>
          MAINTENANCE SCHEDULES
        </span>
        {schedules.length > 0 && (
          <span
            className="px-1.5 py-0.5 rounded"
            style={{
              fontFamily: MONO,
              fontSize: 10,
              fontWeight: 500,
              backgroundColor: "rgba(255,204,0,0.1)",
              color: "#ffcc00",
              border: "1px solid rgba(255,204,0,0.25)",
            }}
          >
            {schedules.length}
          </span>
        )}
      </div>

      {schedules.length === 0 ? (
        <div
          className="py-8 text-center"
          style={{ fontFamily: MONO, fontSize: 11, color: "#4a5568" }}
        >
          No maintenance scheduled. Critical faults auto-generate schedules.
        </div>
      ) : (
        <div className="flex flex-col gap-1.5 max-h-[280px] overflow-y-auto pr-1" style={{ scrollbarWidth: "thin", scrollbarColor: "#1e2530 transparent" }}>
          {schedules.map((s) => {
            const isStopped = !!stoppedMachines[s.machine_id];
            const isConfirmed = s.status === "confirmed";
            const color = isStopped ? "#ff3355" : isConfirmed ? "#ff3355" : "#ffcc00";
            const statusLabel = isStopped ? "HALTED" : isConfirmed ? "CONFIRMED" : s.status === "webhook_sent" ? "AWAITING" : "PENDING";

            return (
              <div
                key={s.id}
                className="rounded px-3 py-2.5"
                style={{
                  backgroundColor: isStopped ? "rgba(255,51,85,0.04)" : "rgba(255,204,0,0.04)",
                  borderLeft: `3px solid ${color}`,
                }}
              >
                <div className="flex items-center gap-2 mb-1">
                  <span
                    className="px-1.5 py-0.5 rounded"
                    style={{
                      fontFamily: MONO,
                      fontSize: 10,
                      fontWeight: 600,
                      backgroundColor: `${color}18`,
                      color,
                      border: `1px solid ${color}40`,
                      letterSpacing: 0.3,
                    }}
                  >
                    {s.machine_id}
                  </span>
                  <span
                    className="px-1 py-px rounded"
                    style={{
                      fontFamily: MONO,
                      fontSize: 9,
                      fontWeight: 600,
                      backgroundColor: `${color}10`,
                      color,
                      letterSpacing: 0.8,
                    }}
                  >
                    [{statusLabel}]
                  </span>
                  <span
                    style={{
                      fontFamily: MONO,
                      fontSize: 10,
                      color: "#4a5568",
                      marginLeft: "auto",
                      whiteSpace: "nowrap",
                    }}
                  >
                    {formatTime(s.created_at)}
                  </span>
                </div>
                <div style={{ fontFamily: MONO, fontSize: 11, color: "#c8d0dc", lineHeight: 1.5, wordBreak: "break-word" }}>
                  {s.reason}
                </div>
                {isStopped && (
                  <button
                    onClick={() => onResume(s.machine_id)}
                    className="px-3 py-1 rounded cursor-pointer mt-2"
                    style={{
                      fontFamily: MONO,
                      fontSize: 10,
                      fontWeight: 600,
                      backgroundColor: "rgba(0,255,136,0.08)",
                      color: "#00ff88",
                      border: "1px solid rgba(0,255,136,0.3)",
                      letterSpacing: 0.5,
                      transition: "background-color 0.15s",
                    }}
                  >
                    ▶ RESUME MACHINE
                  </button>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}