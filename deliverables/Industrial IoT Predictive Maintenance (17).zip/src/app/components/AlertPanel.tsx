import { Alert, MachineId, BASELINES } from "./simulation";

interface AlertPanelProps {
  alerts: Alert[];
}

const severityConfig = {
  critical: {
    label: "CRITICAL",
    color: "#ff3355",
    bg: "rgba(255,51,85,0.08)",
    border: "rgba(255,51,85,0.2)",
    dot: "#ff3355",
    tagBg: "rgba(255,51,85,0.15)",
    tagBorder: "rgba(255,51,85,0.35)",
  },
  warning: {
    label: "HIGH",
    color: "#ffcc00",
    bg: "rgba(255,204,0,0.06)",
    border: "rgba(255,204,0,0.15)",
    dot: "#ffcc00",
    tagBg: "rgba(255,204,0,0.12)",
    tagBorder: "rgba(255,204,0,0.3)",
  },
};

function formatTime(ts: number) {
  const d = new Date(ts);
  const h = d.getHours().toString().padStart(2, "0");
  const m = d.getMinutes().toString().padStart(2, "0");
  const s = d.getSeconds().toString().padStart(2, "0");
  const ampm = d.getHours() >= 12 ? "PM" : "AM";
  const h12 = (d.getHours() % 12 || 12).toString();
  return `${h12}:${m}:${s} ${ampm}`;
}

export function AlertPanel({ alerts }: AlertPanelProps) {
  // Only show panel when there are alerts (i.e., after webhook responded)
  if (alerts.length === 0) return null;

  return (
    <div
      className="rounded-md p-4"
      style={{ backgroundColor: "#111418", border: "1px solid #1a1f28" }}
    >
      {/* Header */}
      <div className="flex items-center gap-2.5 mb-4">
        <div
          className="flex items-center justify-center"
          style={{
            width: 6,
            height: 6,
            borderRadius: "50%",
            backgroundColor: "#ff3355",
            boxShadow: "0 0 8px rgba(255,51,85,0.5)",
            animation: alerts.length > 0 ? "pulse 2s infinite" : undefined,
          }}
        />
        <span style={{ fontFamily: "'Inter', sans-serif", fontWeight: 600, color: "#e2e8f0", fontSize: 14, letterSpacing: 0.5 }}>
          RAISED ALERTS
        </span>
        {alerts.length > 0 && (
          <span
            className="px-1.5 py-0.5 rounded"
            style={{
              fontFamily: "'JetBrains Mono', monospace",
              fontSize: 10,
              fontWeight: 500,
              backgroundColor: "rgba(255,51,85,0.1)",
              color: "#ff3355",
              border: "1px solid rgba(255,51,85,0.25)",
            }}
          >
            {alerts.length}
          </span>
        )}
      </div>

      {alerts.length === 0 ? (
        <div
          className="py-8 text-center"
          style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 11, color: "#4a5568" }}
        >
          No alerts raised. Anomalies with |Z| &ge; 3.0 will appear here.
        </div>
      ) : (
        <div className="flex flex-col gap-1.5 max-h-[400px] overflow-y-auto pr-1" style={{ scrollbarWidth: "thin", scrollbarColor: "#1e2530 transparent" }}>
          {alerts.map((a) => {
            const cfg = severityConfig[a.severity] || severityConfig.warning;
            return (
              <div
                key={a.id}
                className="rounded px-3 py-2.5 flex items-start gap-0"
                style={{
                  backgroundColor: cfg.bg,
                  borderLeft: `3px solid ${cfg.color}`,
                  transition: "background-color 0.2s",
                }}
              >
                {/* Machine ID tag */}
                <span
                  className="shrink-0 px-1.5 py-0.5 rounded mr-2.5"
                  style={{
                    fontFamily: "'JetBrains Mono', monospace",
                    fontSize: 10,
                    fontWeight: 600,
                    backgroundColor: cfg.tagBg,
                    color: cfg.color,
                    border: `1px solid ${cfg.tagBorder}`,
                    letterSpacing: 0.3,
                    marginTop: 1,
                  }}
                >
                  {a.machineId}
                </span>

                {/* Log content */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-0.5">
                    <span
                      className="px-1 py-px rounded"
                      style={{
                        fontFamily: "'JetBrains Mono', monospace",
                        fontSize: 9,
                        fontWeight: 600,
                        backgroundColor: cfg.tagBg,
                        color: cfg.color,
                        letterSpacing: 0.8,
                      }}
                    >
                      [{cfg.label}]
                    </span>
                  </div>
                  <div
                    style={{
                      fontFamily: "'JetBrains Mono', monospace",
                      fontSize: 11,
                      color: "#c8d0dc",
                      lineHeight: 1.5,
                      wordBreak: "break-word",
                    }}
                  >
                    {a.reason}
                  </div>
                </div>

                {/* Timestamp */}
                <span
                  className="shrink-0 ml-3"
                  style={{
                    fontFamily: "'JetBrains Mono', monospace",
                    fontSize: 10,
                    color: "#4a5568",
                    marginTop: 2,
                    whiteSpace: "nowrap",
                  }}
                >
                  {formatTime(a.timestamp)}
                </span>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}