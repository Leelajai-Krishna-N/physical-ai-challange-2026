import { useState, useEffect, useRef, useCallback } from "react";
import {
  MACHINES, BASELINES,
  computeZScores,
  type ServerReading, type Alert, type MachineId,
} from "./components/simulation";
import { MachineCard } from "./components/MachineCard";
import { AlertPanel } from "./components/AlertPanel";
import { WebhookResponsePanel, type WebhookResponse } from "./components/WebhookResponsePanel";
import { MaintenancePanel, type MaintenanceSchedule } from "./components/MaintenancePanel";
import { LiveLog, type LogEntry } from "./components/LiveLog";
import { HeroLanding } from "./components/HeroLanding";
import { Toaster, toast } from "sonner";
import { projectId, publicAnonKey } from "/utils/supabase/info";
import { PredictiveEngine, type MachineState, type FleetContext } from "./components/math-engine";

const ENDPOINTS = [
  { method: "GET", path: "/stream/{machine_id}", color: "#00ff88" },
  { method: "GET", path: "/history/{machine_id}", color: "#00ff88" },
  { method: "POST", path: "/alert", color: "#ffcc00" },
  { method: "POST", path: "/schedule-maintenance", color: "#ffcc00" },
  { method: "GET", path: "/alerts", color: "#00aaff" },
  { method: "GET", path: "/machines", color: "#00aaff" },
];

const WEBHOOK_URL = "https://ghostgopalvarma.app.n8n.cloud/webhook-test/ljk";
const SERVER_URL = "http://localhost:3000";
const SUPABASE_API = `https://${projectId}.supabase.co/functions/v1/make-server-5eb58738`;

type ConnState = "disconnected" | "connecting" | "connected" | "error";

export type N8nDecision = {
  action: "maintenance scheduled" | "alerted" | "none";
  reasoning: string[];
  timestamp: number;
  machineId: string;
};

// Helper to call Supabase server
async function supaFetch(path: string, method: string = "GET", body?: any) {
  try {
    const opts: RequestInit = {
      method,
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${publicAnonKey}` },
    };
    if (body) opts.body = JSON.stringify(body);
    const res = await fetch(`${SUPABASE_API}${path}`, opts);
    return await res.json();
  } catch (e) {
    console.log(`Supabase fetch error ${path}:`, e);
    return null;
  }
}

export default function App() {
  const [clock, setClock] = useState(new Date());
  const [readings, setReadings] = useState<Record<string, ServerReading | null>>({});
  const [sparkData, setSparkData] = useState<Record<string, number[]>>({});
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [connStates, setConnStates] = useState<Record<string, ConnState>>({});
  const [readingCount, setReadingCount] = useState(0);
  const [webhookResponses, setWebhookResponses] = useState<WebhookResponse[]>([]);
  const [maintenanceSchedules, setMaintenanceSchedules] = useState<MaintenanceSchedule[]>([]);
  const [stoppedMachines, setStoppedMachines] = useState<Record<string, any>>({});
  const [n8nDecisions, setN8nDecisions] = useState<Record<string, N8nDecision>>({});

  const windowsRef = useRef<Record<string, ServerReading[]>>({});
  const alertCountRef = useRef(0);
  const lastWebhookRef = useRef<Record<string, number>>({});
  const sourcesRef = useRef<EventSource[]>([]);
  const reconnectTimersRef = useRef<ReturnType<typeof setTimeout>[]>([]);
  const mountedRef = useRef(true);
  const webhookResCountRef = useRef(0);
  const maintenanceTriggeredRef = useRef<Record<string, boolean>>({});
  const schedCountRef = useRef(0);
  const logCountRef = useRef(0);
  const [logEntries, setLogEntries] = useState<LogEntry[]>([]);
  const [showDashboard, setShowDashboard] = useState(false);

  // ─── Predictive Engine ───
  const engineRef = useRef(new PredictiveEngine(MACHINES));
  const [engineStates, setEngineStates] = useState<Record<string, MachineState>>({});
  const [fleetContext, setFleetContext] = useState<FleetContext>({ event_type: null, affected_metric: null, affected_machines: [], consecutive_seconds: 0 });

  const addLog = useCallback((machineId: string, level: LogEntry["level"], message: string) => {
    logCountRef.current++;
    setLogEntries((prev) => [...prev, {
      id: `log-${logCountRef.current}`,
      timestamp: Date.now(),
      machineId,
      level,
      message,
    }].slice(-200));
  }, []);

  useEffect(() => {
    return () => { mountedRef.current = false; };
  }, []);

  // Clock
  useEffect(() => {
    const t = setInterval(() => setClock(new Date()), 1000);
    return () => clearInterval(t);
  }, []);

  // Fresh start on every page load — no persisted state restoration
  useEffect(() => {
    // Clear any persisted stopped machines in Supabase so everything starts clean
    supaFetch("/clear-dashboard-state", "POST");
  }, []);

  // ─── CORE: Handle critical fault → maintenance → webhook → confirmation → stop ───
  const handleCriticalFault = useCallback(async (
    machineId: string, reading: ServerReading, zScores: Record<string, number>, alertObj: Alert
  ) => {
    // Prevent duplicate maintenance for same machine
    if (maintenanceTriggeredRef.current[machineId]) return;
    maintenanceTriggeredRef.current[machineId] = true;

    addLog(machineId, "critical", `CRITICAL FAULT detected. Posting to n8n webhook for decision...`);

    toast.error(`CRITICAL FAULT — ${machineId}`, {
      description: "Awaiting n8n decision...",
      duration: 5000,
    });

    // Build the payload context (but do NOT create schedule yet)
    const readingData = {
      temperature_C: reading.temperature_C,
      vibration_mm_s: reading.vibration_mm_s,
      rpm: reading.rpm,
      current_A: reading.current_A,
    };

    const webhookPayload = {
      machine_id: machineId,
      event: "critical_fault",
      reason: alertObj.reason,
      severity: "critical",
      reading: readingData,
      zScores,
      timestamp: new Date().toISOString(),
      risk_score: engineRef.current.machineStates[machineId]?.risk_score ?? null,
      remaining_life_minutes: engineRef.current.machineStates[machineId]?.remaining_life_minutes ?? null,
      pattern_key: engineRef.current.machineStates[machineId]?.pattern_key || null,
      health_stage: engineRef.current.machineStates[machineId]?.health_stage || null,
      message: `CRITICAL FAULT on ${machineId} — awaiting n8n decision.`,
    };

    // 1) POST to webhook FIRST — wait for n8n decision before creating any schedule
    try {
      let res = await fetch(WEBHOOK_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(webhookPayload),
      });
      if (!res.ok) {
        res = await fetch(WEBHOOK_URL, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(webhookPayload),
        });
      }

      let responseBody: any;
      try { responseBody = await res.clone().json(); } catch { responseBody = await res.text(); }

      // Store webhook response in state
      webhookResCountRef.current++;
      const wrEntry: WebhookResponse = {
        id: `wr-${webhookResCountRef.current}`,
        machineId,
        timestamp: Date.now(),
        status: res.status,
        body: responseBody,
      };
      setWebhookResponses((prev) => [wrEntry, ...prev].slice(0, 50));

      // Store in Supabase
      await supaFetch("/store-webhook-response", "POST", {
        machine_id: machineId,
        status: res.status,
        body: responseBody,
        received_at: new Date().toISOString(),
      });

      if (res.ok && responseBody && typeof responseBody === "object" && responseBody.action) {
        // n8n responded with a valid decision
        const responseMachineId = responseBody.machine_id || machineId;
        const n8nAction = responseBody.action || "none";
        const n8nReasoning = Array.isArray(responseBody.reasoning) ? responseBody.reasoning : [];

        // Add alert to panel — only after webhook returned valid data
        setAlerts((prev) => [alertObj, ...prev].slice(0, 50));

        // Store the n8n decision
        const decision: N8nDecision = {
          action: n8nAction,
          reasoning: n8nReasoning,
          timestamp: Date.now(),
          machineId: responseMachineId,
        };
        setN8nDecisions((prev) => ({ ...prev, [responseMachineId]: decision }));

        const actionLabel = n8nAction === "maintenance scheduled" ? "MAINTENANCE SCHEDULED"
          : n8nAction === "alerted" ? "ALERTED"
          : "FALSE ALARM";

        addLog(machineId, "success", `n8n decision: ${actionLabel} (HTTP ${res.status})`);
        for (const step of n8nReasoning) {
          addLog(machineId, "system", `n8n reasoning: ${step}`);
        }

        if (n8nAction === "maintenance scheduled") {
          // 2) NOW create maintenance schedule — only after n8n confirmed
          const schedPayload = {
            machine_id: machineId,
            reason: alertObj.reason,
            alert_id: alertObj.id,
            severity: "critical",
            zScores,
            reading: readingData,
            risk_score: engineRef.current.machineStates[machineId]?.risk_score ?? null,
            remaining_life_minutes: engineRef.current.machineStates[machineId]?.remaining_life_minutes ?? null,
            pattern_key: engineRef.current.machineStates[machineId]?.pattern_key || null,
            health_stage: engineRef.current.machineStates[machineId]?.health_stage || null,
            should_shutdown: true,
          };

          const schedRes = await supaFetch("/schedule-maintenance", "POST", schedPayload);
          const schedule = schedRes?.schedule;

          if (schedule) {
            // Mark as already confirmed since n8n already approved
            schedule.status = "confirmed";
            schedule.confirmed_at = new Date().toISOString();
            setMaintenanceSchedules((prev) => [schedule, ...prev]);
            addLog(machineId, "system", `Maintenance schedule created & confirmed: ${schedule.id}`);

            toast.error(`n8n: MAINTENANCE SCHEDULED — ${machineId}`, {
              description: n8nReasoning[0] || "Halting machine stream...",
              duration: 6000,
            });

            // Confirm in Supabase & mark machine stopped
            await supaFetch("/confirm-maintenance", "POST", {
              schedule_id: schedule.id,
              machine_id: machineId,
              webhook_response: responseBody,
            });

            // Stop the machine — close SSE stream, clear data
            setStoppedMachines((prev) => ({
              ...prev,
              [machineId]: {
                stopped_at: new Date().toISOString(),
                schedule_id: schedule.id,
                reason: "Maintenance scheduled by n8n — machine halted",
              },
            }));

            // Close the specific SSE stream
            sourcesRef.current = sourcesRef.current.filter((es) => {
              if (es.url.includes(machineId)) {
                es.close();
                return false;
              }
              return true;
            });

            // Clear readings and spark data for stopped machine
            setReadings((prev) => ({ ...prev, [machineId]: null }));
            setSparkData((prev) => ({ ...prev, [machineId]: [] }));
            setConnStates((prev) => ({ ...prev, [machineId]: "disconnected" }));
            addLog(machineId, "critical", `Machine HALTED. SSE stream closed, data cleared.`);
          }

        } else if (n8nAction === "alerted") {
          toast.warning(`n8n: ALERTED — ${machineId}`, {
            description: n8nReasoning[0] || "Alert logged, machine continues running.",
            duration: 5000,
          });
          maintenanceTriggeredRef.current[machineId] = false; // allow future triggers

        } else {
          // "none" → false alarm
          toast.success(`n8n: FALSE ALARM — ${machineId}`, {
            description: n8nReasoning[0] || "No action required.",
            duration: 5000,
          });
          maintenanceTriggeredRef.current[machineId] = false; // allow future triggers
        }

      } else {
        // Webhook failed or returned non-actionable data — no schedule created
        addLog(machineId, "warning", `Webhook returned no actionable decision (HTTP ${res.status}). No schedule created.`);
        toast.error(`No n8n decision for ${machineId} — HTTP ${res.status}`, { duration: 4000 });
        maintenanceTriggeredRef.current[machineId] = false; // allow future triggers
      }
    } catch {
      // Webhook unreachable — no schedule created
      toast.error(`Webhook unreachable — ${machineId}`, { duration: 4000 });
      addLog(machineId, "critical", `Webhook network error — n8n unreachable. No schedule created.`);
      maintenanceTriggeredRef.current[machineId] = false; // allow retry
    }
  }, [addLog]);

  // Post anomaly to webhook (for non-critical / warning anomalies)
  const postToWebhook = useCallback(async (machineId: string, reading: ServerReading, zScores: Record<string, number>, alertObj: Alert) => {
    if (stoppedMachines[machineId]) return;
    const now = Date.now();
    if (now - (lastWebhookRef.current[machineId] || 0) < 10000) return;
    lastWebhookRef.current[machineId] = now;

    const w = windowsRef.current[machineId] || [];
    const rpmVals = w.map((r) => r.rpm).sort((a, b) => a - b);
    const median = rpmVals.length > 0 ? rpmVals[Math.floor(rpmVals.length / 2)] : reading.rpm;
    const deviations = rpmVals.map((v) => Math.abs(v - median)).sort((a, b) => a - b);
    const mad = deviations.length > 0 ? deviations[Math.floor(deviations.length / 2)] : 0;

    const payload = {
      machine_id: machineId,
      event: "anomaly_detected",
      timestamp: new Date().toISOString(),
      rpm: { current: Math.round(reading.rpm), median: Math.round(median), mad: Math.round(mad), score: parseFloat(Math.abs(zScores.rpm).toFixed(4)) },
      zScores: {
        temperature: parseFloat(zScores.temperature.toFixed(4)),
        vibration: parseFloat(zScores.vibration.toFixed(4)),
        current: parseFloat(zScores.current.toFixed(4)),
        pressure: parseFloat((zScores.rpm * 0.8).toFixed(4)),
        rpm: parseFloat(zScores.rpm.toFixed(4)),
      },
    };

    const addResponse = (status: number, body: any) => {
      webhookResCountRef.current++;
      setWebhookResponses((prev) => [{
        id: `wr-${webhookResCountRef.current}`,
        machineId,
        timestamp: Date.now(),
        status,
        body,
      }, ...prev].slice(0, 50));
    };

    try {
      let res = await fetch(WEBHOOK_URL, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) });
      if (!res.ok) res = await fetch(WEBHOOK_URL, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) });
      let responseBody: any;
      try { responseBody = await res.clone().json(); } catch { responseBody = await res.text(); }
      addResponse(res.status, responseBody);

      // Store in Supabase
      await supaFetch("/store-webhook-response", "POST", {
        machine_id: machineId,
        event: "anomaly",
        status: res.status,
        body: responseBody,
        received_at: new Date().toISOString(),
      });

      if (res.ok) {
        // Parse n8n action/reasoning from warning webhook too
        if (responseBody && typeof responseBody === "object" && responseBody.action) {
          const responseMachineId = responseBody.machine_id || machineId;
          const n8nAction = responseBody.action || "none";
          const n8nReasoning = Array.isArray(responseBody.reasoning) ? responseBody.reasoning : [];
          const decision: N8nDecision = { action: n8nAction, reasoning: n8nReasoning, timestamp: Date.now(), machineId: responseMachineId };
          setN8nDecisions((prev) => ({ ...prev, [responseMachineId]: decision }));

          // NOW add alert to panel — only after webhook returned valid data
          setAlerts((prev) => [alertObj, ...prev].slice(0, 50));

          const actionLabel = n8nAction === "maintenance scheduled" ? "MAINTENANCE SCHEDULED"
            : n8nAction === "alerted" ? "ALERTED" : "FALSE ALARM";
          addLog(responseMachineId, "system", `n8n decision: ${actionLabel}`);
          for (const step of n8nReasoning) {
            addLog(responseMachineId, "system", `n8n reasoning: ${step}`);
          }

          toast.success(`n8n: ${actionLabel} — ${responseMachineId}`, {
            description: n8nReasoning[0] || `Z: temp=${payload.zScores.temperature} vib=${payload.zScores.vibration}`,
            duration: 4000,
          });
        } else {
          toast.success(`Webhook posted — ${machineId}`, { description: `Z: temp=${payload.zScores.temperature} vib=${payload.zScores.vibration}`, duration: 3000 });
        }
      } else toast.error(`Webhook failed — ${machineId}`, { duration: 3000 });
    } catch {
      // Don't push error entries — panel only shows valid n8n responses
      toast.error(`Webhook unreachable — ${machineId}`, { duration: 3000 });
    }
  }, [stoppedMachines]);

  const generateAlertReason = useCallback((machineId: string, reading: ServerReading, zScores: Record<string, number>) => {
    const parts: string[] = [];
    const b = BASELINES[machineId as MachineId];
    if (!b) return "Multi-metric anomaly detected";
    if (Math.abs(zScores.temperature) >= 3.0) parts.push(`Temperature is ${reading.temperature_C.toFixed(2)} C above the 3Bs baseline around ${b.temp.toFixed(2)} C`);
    if (Math.abs(zScores.vibration) >= 3.0) parts.push(`Vibration is ${reading.vibration_mm_s.toFixed(2)} mm/s above the 3Bs baseline around ${b.vib.toFixed(2)} mm/s`);
    if (Math.abs(zScores.current) >= 3.0) parts.push(`Current is ${reading.current_A.toFixed(2)} A above the 3Bs baseline around ${b.current.toFixed(2)} A`);
    if (Math.abs(zScores.rpm) >= 3.0) parts.push(`RPM is ${reading.rpm.toFixed(0)} above the 3Bs baseline around ${b.rpm}`);
    if (parts.length > 1) {
      return parts.join(". ") + ". Pattern match: multi-parameter deviation consistent with systemic fault.";
    }
    return parts.length > 0 ? parts.join(". ") + "." : "Multi-metric anomaly detected";
  }, []);

  const processReading = useCallback((machineId: string, reading: ServerReading) => {
    // Skip if machine is stopped
    if (stoppedMachines[machineId]) return;

    setReadings((prev) => ({ ...prev, [machineId]: reading }));
    setReadingCount((c) => c + 1);
    setSparkData((prev) => {
      const arr = [...(prev[machineId] || []), reading.vibration_mm_s];
      if (arr.length > 60) arr.shift();
      return { ...prev, [machineId]: arr };
    });

    // Store every 10th reading to Supabase (avoid flooding)
    if (Math.random() < 0.1) {
      supaFetch("/store-reading", "POST", { ...reading, machine_id: machineId });
    }

    // ─── Feed into PredictiveEngine ───
    const engineState = engineRef.current.processReading(machineId, reading);
    const queue = engineRef.current.computePriorityQueue();
    setEngineStates((prev) => {
      const next = { ...prev };
      for (const s of queue) next[s.machine_id] = s;
      // Also include non-queued machines (like CONVEYOR_04 sentinel)
      if (!next[machineId]) next[machineId] = engineState;
      return next;
    });
    setFleetContext({ ...engineRef.current.fleetContext });

    // Log fleet events
    if (engineRef.current.fleetContext.event_type && engineRef.current.fleetContext.consecutive_seconds === 3) {
      addLog(machineId, "system", `FLEET EVENT: ${engineRef.current.fleetContext.event_type} detected on ${engineRef.current.fleetContext.affected_metric} — ${engineRef.current.fleetContext.affected_machines.join(", ")}`);
    }

    // Log compound signatures
    for (const sig of engineState.compound_signatures) {
      if (sig.active && engineState.readings_since_connect % 30 === 0) {
        addLog(machineId, "warning", `SIGNATURE: ${sig.name.toUpperCase().replace(/_/g, " ")} — ${sig.description}`);
      }
    }

    const w = windowsRef.current[machineId] || [];
    w.push(reading);
    if (w.length > 20) w.shift();
    windowsRef.current[machineId] = w;

    if (w.length >= 10) {
      const zScores = computeZScores(w);
      const anomalies = Object.entries(zScores).filter(([, z]) => Math.abs(z) >= 3.0);
      if (anomalies.length > 0) {
        alertCountRef.current++;
        const alertObj: Alert = {
          id: `alert-${alertCountRef.current}`,
          machineId,
          reason: generateAlertReason(machineId, reading, zScores),
          timestamp: Date.now(),
          severity: reading.status === "fault" ? "critical" : "warning",
        };
        // Do NOT add alert to panel yet — only show after webhook responds
        addLog(machineId, reading.status === "fault" ? "critical" : "warning", alertObj.reason);

        // Store alert in Supabase with full engine context
        const es = engineStates[machineId] || engineRef.current.machineStates[machineId];
        supaFetch("/store-alert", "POST", {
          ...alertObj,
          machine_id: machineId,
          parameters: {
            temperature_C: reading.temperature_C,
            vibration_mm_s: reading.vibration_mm_s,
            rpm: reading.rpm,
            current_A: reading.current_A,
          },
          zScores,
          // Engine context
          risk_score: es?.risk_score ?? null,
          health_stage: es?.health_stage || null,
          operating_phase: es?.operating_phase || null,
          pattern_key: es?.pattern_key || null,
          remaining_life_minutes: es?.remaining_life_minutes ?? null,
          priority_score_math: es?.priority_score_math ?? null,
          priority_rank: es?.priority_rank ?? null,
          is_top_ticket: es?.is_top_ticket || false,
          fleet_event_type: es?.fleet_event_type || null,
          metric_scores: es?.metric_scores || null,
          should_shutdown: reading.status === "fault",
        });

        if (reading.status === "fault") {
          // CRITICAL RED FAULT → trigger maintenance flow
          handleCriticalFault(machineId, reading, zScores, alertObj);
        } else {
          // Warning-level → just post to webhook
          postToWebhook(machineId, reading, zScores, alertObj);
        }
      }
    }
  }, [postToWebhook, generateAlertReason, handleCriticalFault, stoppedMachines, addLog]);

  // Cleanup
  const disconnectAll = useCallback(() => {
    sourcesRef.current.forEach((es) => { try { es.close(); } catch {} });
    sourcesRef.current = [];
    reconnectTimersRef.current.forEach((t) => clearTimeout(t));
    reconnectTimersRef.current = [];
  }, []);

  // Open SSE streams for all machines
  const openStreams = useCallback((baseUrl: string) => {
    disconnectAll();

    for (const machineId of MACHINES) {
      // Don't open stream for stopped machines
      if (stoppedMachines[machineId]) {
        setConnStates((prev) => ({ ...prev, [machineId]: "disconnected" }));
        continue;
      }

      windowsRef.current[machineId] = [];

      const connect = () => {
        if (!mountedRef.current) return;
        if (stoppedMachines[machineId]) return;
        setConnStates((prev) => ({ ...prev, [machineId]: "connecting" }));

        const es = new EventSource(`${baseUrl}/stream/${machineId}`);
        sourcesRef.current.push(es);

        es.onopen = () => {
          if (!mountedRef.current) return;
          setConnStates((prev) => ({ ...prev, [machineId]: "connected" }));
        };

        es.onmessage = (event) => {
          if (!mountedRef.current) return;
          try {
            const reading: ServerReading = JSON.parse(event.data);
            processReading(machineId, reading);
            setConnStates((prev) => prev[machineId] === "connected" ? prev : { ...prev, [machineId]: "connected" });
          } catch {}
        };

        es.onerror = () => {
          if (!mountedRef.current) return;
          setConnStates((prev) => ({ ...prev, [machineId]: "error" }));
          es.close();
          sourcesRef.current = sourcesRef.current.filter((s) => s !== es);
          if (!stoppedMachines[machineId]) {
            const timer = setTimeout(connect, 3000);
            reconnectTimersRef.current.push(timer);
          }
        };
      };

      connect();
    }
  }, [disconnectAll, processReading, stoppedMachines]);

  // Auto-connect on mount
  useEffect(() => {
    openStreams(SERVER_URL);
    return () => { disconnectAll(); };
  }, [openStreams, disconnectAll]);

  // Resume machine handler
  const handleResumeMachine = useCallback(async (machineId: string) => {
    await supaFetch("/resume-machine", "POST", { machine_id: machineId });
    setStoppedMachines((prev) => {
      const next = { ...prev };
      delete next[machineId];
      return next;
    });
    maintenanceTriggeredRef.current[machineId] = false;
    setReadings((prev) => ({ ...prev, [machineId]: null }));
    setSparkData((prev) => ({ ...prev, [machineId]: [] }));
    windowsRef.current[machineId] = [];
    toast.success(`${machineId} RESUMED`, { description: "Reconnecting SSE stream...", duration: 3000 });

    // Reset predictive engine state for this machine
    engineRef.current.resetMachine(machineId);

    // Clear n8n decision for this machine
    setN8nDecisions((prev) => {
      const next = { ...prev };
      delete next[machineId];
      return next;
    });

    // Reconnect this machine's stream
    setTimeout(() => {
      const connect = () => {
        if (!mountedRef.current) return;
        setConnStates((prev) => ({ ...prev, [machineId]: "connecting" }));
        const es = new EventSource(`${SERVER_URL}/stream/${machineId}`);
        sourcesRef.current.push(es);
        es.onopen = () => {
          if (!mountedRef.current) return;
          setConnStates((prev) => ({ ...prev, [machineId]: "connected" }));
        };
        es.onmessage = (event) => {
          if (!mountedRef.current) return;
          try {
            const reading: ServerReading = JSON.parse(event.data);
            processReading(machineId, reading);
            setConnStates((prev) => prev[machineId] === "connected" ? prev : { ...prev, [machineId]: "connected" });
          } catch {}
        };
        es.onerror = () => {
          if (!mountedRef.current) return;
          setConnStates((prev) => ({ ...prev, [machineId]: "error" }));
          es.close();
          sourcesRef.current = sourcesRef.current.filter((s) => s !== es);
          const timer = setTimeout(connect, 3000);
          reconnectTimersRef.current.push(timer);
        };
      };
      connect();
    }, 500);
  }, [processReading]);

  const connectedCount = Object.values(connStates).filter((s) => s === "connected").length;
  const stoppedCount = Object.keys(stoppedMachines).length;

  if (!showDashboard) {
    return <HeroLanding onEnter={() => setShowDashboard(true)} />;
  }

  return (
    <div className="min-h-screen" style={{ backgroundColor: "#0a0c10", fontFamily: "'Inter', sans-serif" }}>
      <div className="mx-auto" style={{ maxWidth: 1440, padding: "16px 24px" }}>

        {/* HEADER */}
        <div className="flex items-center justify-between mb-4 pb-3" style={{ borderBottom: "1px solid #1e2530" }}>
          <div className="flex items-center gap-3">
            <div style={{ color: "#e2e8f0", fontSize: 20, fontWeight: 600, letterSpacing: 0.5 }}>
              <span style={{ color: "#00ff88" }}>&#9881;</span> KAIROS — Sensor Dashboard
            </div>
            <span
              className="px-2 py-0.5 rounded"
              style={{
                fontFamily: "'JetBrains Mono', monospace",
                fontSize: 10,
                backgroundColor: connectedCount === 4 ? "#00ff8815" : connectedCount > 0 ? "#ffcc0015" : "#ff335515",
                color: connectedCount === 4 ? "#00ff88" : connectedCount > 0 ? "#ffcc00" : "#ff3355",
                border: `1px solid ${connectedCount === 4 ? "#00ff8840" : connectedCount > 0 ? "#ffcc0040" : "#ff335540"}`,
              }}
            >
              {connectedCount === 4 ? `LIVE — 4/4 SSE` : connectedCount > 0 ? `${connectedCount}/4 STREAMS` : "RECONNECTING..."}
            </span>
            {stoppedCount > 0 && (
              <span
                className="px-2 py-0.5 rounded"
                style={{
                  fontFamily: "'JetBrains Mono', monospace",
                  fontSize: 10,
                  backgroundColor: "#ff335515",
                  color: "#ff3355",
                  border: "1px solid #ff335540",
                }}
              >
                {stoppedCount} HALTED
              </span>
            )}
            {readingCount > 0 && (
              <span style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 10, color: "#4a5568" }}>
                {readingCount} readings
              </span>
            )}
          </div>
          <div style={{ fontFamily: "'JetBrains Mono', monospace", color: "#00aaff", fontSize: 13 }}>
            {clock.toISOString().replace("T", " ").slice(0, 19)} UTC
          </div>
        </div>

        {/* API ENDPOINTS */}
        <div className="flex flex-wrap gap-2 mb-4 p-3 rounded-sm items-center" style={{ backgroundColor: "#111418", border: "1px solid #1e2530" }}>
          <span style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 10, color: "#00ff88", marginRight: 4 }}>
            {SERVER_URL}
          </span>
          {ENDPOINTS.map((e) => (
            <span key={e.path + e.method} className="px-2 py-0.5 rounded" style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 10, backgroundColor: "#0a0c10", border: "1px solid #1a1f28", color: e.color }}>
              <span style={{ color: "#4a5568" }}>{e.method}</span> {e.path}
            </span>
          ))}
          <span className="px-2 py-0.5 rounded" style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 10, backgroundColor: "#0a0c10", border: "1px solid #1a1f28", color: "#00aaff" }}>
            <span style={{ color: "#4a5568" }}>SUPABASE</span> MACHINE_LOGS
          </span>
        </div>

        {/* FLEET CONTEXT BANNER */}
        {fleetContext.event_type && (
          <div
            className="flex items-center gap-3 mb-4 px-4 py-2.5 rounded-md"
            style={{
              backgroundColor: "rgba(139,92,246,0.06)",
              border: "1px solid rgba(139,92,246,0.2)",
            }}
          >
            <div
              style={{
                width: 8, height: 8, borderRadius: "50%",
                backgroundColor: "#8b5cf6",
                boxShadow: "0 0 10px rgba(139,92,246,0.5)",
                animation: "pulse 2s infinite",
              }}
            />
            <span style={{ fontFamily: "'Inter', sans-serif", fontWeight: 600, color: "#8b5cf6", fontSize: 12, letterSpacing: 0.5 }}>
              FLEET EVENT ACTIVE
            </span>
            <span
              className="px-2 py-0.5 rounded"
              style={{
                fontFamily: "'JetBrains Mono', monospace", fontSize: 10, fontWeight: 600,
                backgroundColor: "rgba(139,92,246,0.12)", color: "#8b5cf6",
                border: "1px solid rgba(139,92,246,0.3)",
              }}
            >
              {fleetContext.event_type?.toUpperCase().replace(/-/g, " ")}
            </span>
            <span style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 10, color: "#94a3b8" }}>
              {fleetContext.affected_metric?.toUpperCase()} across {fleetContext.affected_machines.join(", ")}
            </span>
            <span style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 10, color: "#4a5568", marginLeft: "auto" }}>
              {fleetContext.consecutive_seconds}s sustained — per-machine maintenance suppressed
            </span>
          </div>
        )}

        {/* MACHINE GRID + PANELS */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          <div className="lg:col-span-2 grid grid-cols-1 sm:grid-cols-2 gap-4">
            {MACHINES.map((m) => (
              <MachineCard
                key={m}
                machineId={m}
                reading={stoppedMachines[m] ? null : (readings[m] || null)}
                sparkData={stoppedMachines[m] ? [] : (sparkData[m] || [])}
                connected={connStates[m] === "connected"}
                stopped={!!stoppedMachines[m]}
                engineState={engineStates[m] || null}
                n8nDecision={n8nDecisions[m] || null}
              />
            ))}
          </div>
          <div>
            <AlertPanel alerts={alerts} />
            <MaintenancePanel
              schedules={maintenanceSchedules}
              stoppedMachines={stoppedMachines}
              onResume={handleResumeMachine}
            />
            <WebhookResponsePanel responses={webhookResponses} />
          </div>
        </div>

        {/* LIVE ACTIVITY LOG — full width below machines */}
        <LiveLog entries={logEntries} />

        {/* Footer */}
        <div className="mt-6 pt-3 text-center" style={{ borderTop: "1px solid #1e2530" }}>
          <span style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 10, color: "#4a5568" }}>
            KAIROS v3.0 — ADAPTIVE BASELINES — THEIL-SEN TRENDS — RUL ESTIMATION — FLEET CORRELATION — PRIORITY QUEUE — SUPABASE MACHINE_LOGS
          </span>
        </div>
      </div>
      <Toaster position="bottom-right" theme="dark" toastOptions={{ style: { background: "#111418", border: "1px solid #1a1f28", color: "#e2e8f0", fontFamily: "'JetBrains Mono', monospace", fontSize: 12 } }} />
    </div>
  );
}