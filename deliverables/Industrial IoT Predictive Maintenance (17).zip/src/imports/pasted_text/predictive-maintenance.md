You are implementing a high-impact, judge-facing predictive-maintenance upgrade in this repo:

C:\physical-ai-challange-2026\external\malendau-hackathon

Read the existing implementation first and preserve what already works. Do not redesign from scratch unless required.

Primary files to inspect first:
- agent.js
- agent/config.js
- agent/risk.js
- agent/baseline.js
- agent/actions.js
- agent/coordinator.js
- agent/dashboard-state.js
- agent/history-memory.js
- agent/retrieval-adapter.js
- scripts/watchdog.py
- server.js
- docs/n8n-ai-decision-engine.workflow.json
- all tests under test/

Current repo truths you must respect:
- There is already a statistical/rule-based core.
- There is already ticketing and a priority queue concept.
- There is already optional retrieval/FAISS and optional LLM/n8n wiring.
- CONVEYOR_04 exists as a healthy sentinel, but it must NOT be the main baseline for all machines.

Locked product decisions:
- Every machine must have its own relative adaptive baseline.
- Use rolling/sliding windows, not tumbling/fixed windows.
- FAISS is disabled by default and should be de-emphasized.
- LLM stays in the project and MAY output final action decisions, including:
  - ticket priority
  - maintenance scheduling decision
  - shutdown decision
- However, do not send raw telemetry to the LLM.
- The LLM must receive only a compact structured evidence packet built by the math layer.
- If many machines fail simultaneously, create a clear priority queue and raise the highest-priority ticket first.
- Maintenance scheduling records do not store priority.
- Machines that are scheduled for maintenance should be switched off and this must be reflected clearly in the dashboard.
- Supabase integration may block on manual table creation by the user’s teammate. If so, generate the exact SQL and STOP, then wait for the user to confirm the tables are created before continuing.

Main goal:
Build a mathematically rigorous, LLM-augmented predictive-maintenance system where:
1. statistics detect and compress the event,
2. per-machine and fleet context make the evidence meaningful,
3. LLM decides queueing/ticket/scheduling/shutdown for anomaly candidates only,
4. Supabase stores the alert stream and maintenance schedule history,
5. the dashboard clearly shows machine state, queue state, power/shutdown state, and maintenance state.

A. Per-machine adaptive relative baselines
Every machine needs:
1. Historical per-machine time-of-day baseline
2. Rolling healthy per-machine adaptive baseline
3. Fleet-context baseline
4. Optional sentinel comparison using CONVEYOR_04

Use these formulas:

Historical center and scale for machine i, metric m, bucket b:
- center_hist(i,m,b) = median(history_bucket)
- scale_hist(i,m,b) = max(1.4826 * MAD(history_bucket), std(history_bucket), 0.02 * abs(center_hist), eps)

Use eps = 1e-3 or similar.

Adaptive healthy offset for shift-aware metrics like temperature/current:
- offset_t = beta * offset_(t-1) + (1 - beta) * (x_t - center_hist)
- beta = 0.95
- only update during healthy windows and when no fleet-wide event is active

Effective center:
- center_eff = center_hist + offset_t

Direction-aware z-score:
- high-bad metrics (temperature, vibration, current):
  z_t = (x_t - center_eff) / scale_hist
- low-bad metrics (rpm):
  z_t = (center_eff - x_t) / scale_hist

B. Standard rolling windows
Use these exact values everywhere:
- fast anomaly gate = 20 samples at 1 Hz
- short confirmation window = 30 samples
- long degradation window = 600 samples
- fleet-context window = 60 samples
- historical baseline bucket = 15 minutes

Unify these across:
- watchdog
- agent
- workflow logic

C. Robust scoring and trends
Use robust scoring, not naive mean-only logic.

Persistence in window W:
- persistence_W = count(z > 2.0 in W) / len(W)

Use Theil-Sen slope for long-window trend estimation over the 600-second window.

Short-window anomaly score for metric m:
- short_score_m_raw = 0.5 * median(z_30 positive only) + 0.3 * max(z_30 positive only) + 0.2 * (4 * persistence_30)
- scale into a practical 0-100 score

Long-window degradation score:
- long_score_m_raw = 0.5 * median(z_600 positive only) + 0.25 * (4 * persistence_600) + 0.25 * normalized_trend
- normalized_trend = max(0, slope_toward_failure / scale_hist)

Machine-specific metric weights:
- CNC_01: vibration 0.45, temperature 0.35, current 0.20
- CNC_02: temperature 0.50, current 0.30, vibration 0.20
- PUMP_03: rpm 0.45, vibration 0.35, current 0.20
- CONVEYOR_04: sentinel only, never auto-schedule maintenance

Keep or improve compound signatures:
- CNC_01: bearing wear = vibration + temperature + current rising together
- CNC_02: thermal runaway = temperature + current elevation together
- PUMP_03: cavitation/clog = vibration bursts + rpm drop + current rise

D. Remaining useful life
Add these fields to machine state:
- remaining_life_minutes
- rul_confidence
- health_stage
- operating_phase

Failure limit:
- high-bad metric limit = max(p99, center_eff + 3.5 * scale_hist)
- low-bad metric limit = center_eff - 3.5 * scale_hist

Metric RUL:
- if slope moves toward failure:
  time_to_limit = (limit - current_value) / slope
- else infinity

Machine RUL:
- RUL_machine = minimum credible metric time_to_limit among fault-relevant metrics

RUL confidence should decrease if:
- slope is unstable
- evidence is weak
- fleet event is active
- startup/reconnect phase is active

Health stages:
- healthy
- aging
- degraded
- critical

E. Operating phases
Add:
- startup
- steady
- high_load
- low_load

Rules:
- startup = first 30 readings after reconnect or fresh warm start
- suppress non-hard alerts during startup
- high_load and low_load should influence interpretation and explanation

F. Fleet correlation / plant context
Implement cross-machine correlation to separate local faults from environmental/process effects.

Fleet event rule:
- if at least 3 of 4 machines show same-sign |z| >= 2.5 on same metric for 3 consecutive seconds inside the 60-second fleet window, trigger plant-wide event

Fleet event classes:
- ambient-shift
- power-quality-load-event
- unknown-fleet-event

Behavior:
- if temperature rises across most machines together, treat it as likely plant/ambient issue first
- if current/rpm disturbance hits most machines together, suspect plant load/power/process issue
- suppress per-machine maintenance for pure fleet events
- expose fleet_context in state, dashboard, and LLM evidence

This is how the system should enable explanations like:
- “2:30 pm temperature rise is more consistent with ambient heat / solar load / ventilation conditions than machine-specific wear”
but only when structured evidence supports it

G. Priority queue for simultaneous failures
When many machines fail together:
- insert every anomaly candidate into the alerts/events pipeline
- compute a deterministic math pre-priority score
- then let the LLM output final queueing decisions

Math pre-priority score:
- risk_norm = risk_score / 100
- rul_urgency = clamp((240 - min(RUL, 240)) / 240, 0, 1)
- persistence_norm = persistence_600
- hard_fault_bonus = 1 if hard fault else 0
- fleet_isolation = 1 if machine-specific else 0.4 if fleet-wide
- priority_score_math = 100 * (
    0.35 * risk_norm +
    0.25 * rul_urgency +
    0.15 * persistence_norm +
    0.15 * hard_fault_bonus +
    0.10 * fleet_isolation
  )

Rules:
- create all alert rows
- rank all active alerts
- raise/open the highest-priority ticket first
- keep the rest queued
- maintenance table itself must not store queue priority
- queue priority must be visible in the dashboard

H. LLM action layer
The LLM is allowed to output final action decisions, but only from compact anomaly evidence packets.

The LLM must NOT receive raw per-second windows unless already summarized.
The LLM must receive:
- machine_id
- timestamp
- operating_phase
- fleet_context
- current metrics
- top z-scores
- short score
- long score
- Theil-Sen slopes
- persistence values
- compound signature matches
- remaining_life_minutes
- health_stage
- recent alert/ticket context
- whether sentinel moved similarly
- math pre-priority score
- current queue snapshot if multiple machines are active

The LLM must return strict JSON with:
- final_status
- operator_summary
- suspected_root_cause
- inspection_steps
- maintenance_note
- ticket_action
- priority_rank
- priority_reason
- maintenance_decision
- maintenance_slot_preference
- should_shutdown
- shutdown_reason
- explanation_confidence

Allowed values:
- ticket_action: open_ticket | merge_with_existing | suppress
- maintenance_decision: schedule_now | schedule_next_slot | monitor_only
- final_status: NORMAL | WARNING | CRITICAL

Behavior:
- If multiple machines are active, the LLM must rank them and identify the top-priority ticket.
- If maintenance_decision is schedule_now or schedule_next_slot, the machine should be marked for shutdown.
- The dashboard must clearly show power state:
  - RUNNING
  - QUEUED_FOR_SHUTDOWN
  - SHUTDOWN
- Store LLM decision JSON on the alert row and maintenance row where relevant.

Use event fingerprint caching to reduce token burn:
- fingerprint = machine_id + pattern_key + operating_phase + top_metrics + fleet_context + time_bucket
- reuse similar explanations/decisions for 15-30 minutes where safe

LLM wake policy:
- wake only if risk >= 60 OR RUL < 240 OR hard fault OR fleet event OR more than one machine is in active anomaly state

I. Supabase schema
Create two new tables only.

Table 1: industrial_alert_events
Suggested columns:
- id uuid primary key default gen_random_uuid()
- machine_id text not null
- event_timestamp timestamptz not null
- final_status text not null
- operating_phase text
- pattern_key text
- fleet_event_type text
- current_metrics jsonb not null
- metric_scores jsonb not null
- trend_metrics jsonb
- persistence_metrics jsonb
- risk_score numeric
- remaining_life_minutes numeric
- health_stage text
- priority_score_math numeric
- priority_rank integer
- ticket_action text
- priority_reason text
- top_ticket boolean default false
- should_shutdown boolean default false
- shutdown_reason text
- llm_decision jsonb
- source text
- created_at timestamptz default now()

Table 2: industrial_maintenance_schedule
Suggested columns:
- id uuid primary key default gen_random_uuid()
- machine_id text not null
- alert_event_id uuid references industrial_alert_events(id)
- maintenance_decision text not null
- maintenance_slot_preference text
- scheduled_slot timestamptz
- technician text
- status text
- actions jsonb
- estimated_downtime_minutes numeric
- should_shutdown boolean default false
- shutdown_at timestamptz
- shutdown_reason text
- llm_decision jsonb
- created_at timestamptz default now()

Important:
- priority must live in alert events / queue logic, not in maintenance table
- one row per alert event
- one row per maintenance scheduling decision

J. Pause-and-resume behavior for Supabase
If Supabase credentials or table creation are missing:
1. Generate exact SQL `CREATE TABLE` statements and any required indexes
2. Explain the required env vars / credentials
3. STOP and print exactly:
   PAUSE_FOR_SUPABASE_SETUP
4. Do not continue with integration that depends on those tables
5. Wait for user confirmation:
   “Supabase tables created, resume”
6. On resume, continue with:
   - wiring inserts/updates
   - queue logic
   - dashboard integration
   - tests

K. Dashboard requirements
Dashboard must clearly show:
- per-machine current status
- current risk
- remaining life
- operating phase
- fleet context
- queue rank
- whether this is the top-priority ticket
- maintenance decision
- power state: RUNNING / QUEUED_FOR_SHUTDOWN / SHUTDOWN
- shutdown reason
- maintenance slot / technician / downtime if scheduled

If a machine is scheduled for maintenance:
- clearly reflect that it is being switched off
- update dashboard state immediately

L. Maintenance API / server updates
Expand server-side maintenance scheduling logic.
Request payload should include:
- machine_id
- alert_event_id
- risk_score
- remaining_life_minutes
- pattern_key
- recommended_action
- action_plan
- source
- requested_by
- should_shutdown

Response should include:
- booking.id
- slot
- technician
- status
- actions
- estimated_downtime_minutes
- booked_at
- reason
- shutdown_confirmed

M. Tests
Add/update tests for:
- per-machine adaptive baselines
- standardized windows
- RUL decline for degrading machines
- fleet-wide spike suppression
- simultaneous multi-machine queue ranking
- highest-priority ticket selection
- maintenance row creation without priority field
- shutdown state propagation to dashboard
- LLM decision JSON shape
- Supabase pause/resume flow behavior where possible
- LLM-off and FAISS-off fallback behavior
- full suite passing

N. Docs
Add a short judge FAQ / architecture note that explains:
- why every machine has its own adaptive baseline
- why rolling windows are used
- why fleet correlation is necessary
- why RUL matters
- why the LLM is worth the tokens
- why the LLM is only called on compressed anomaly evidence, not raw streams
- how simultaneous failures are prioritized
- what happens after maintenance scheduling
- how shutdown is reflected in the dashboard

What success looks like:
- mathematically grounded detection
- impressive LLM-driven actioning on top of compact evidence
- low token waste
- obvious queueing and shutdown behavior in the UI
- Supabase-backed alert and maintenance history
- a design that feels more advanced than rule-only systems, but still disciplined and explainable

Expected output from you:
1. inspect the current repo
2. implement the code cleanly
3. generate SQL and pause if Supabase setup is needed
4. resume after user confirmation
5. update tests
6. update docs
7. run tests
8. summarize changes and remaining limitations
9. give a short final judge pitch
