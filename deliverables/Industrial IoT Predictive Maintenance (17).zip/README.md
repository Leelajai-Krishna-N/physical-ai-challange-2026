
  # Industrial IoT Predictive Maintenance

  This is a code bundle for Industrial IoT Predictive Maintenance. The original project is available at https://www.figma.com/design/T6ygH5WtZtA4qbuCdEnBZP/Industrial-IoT-Predictive-Maintenance.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  