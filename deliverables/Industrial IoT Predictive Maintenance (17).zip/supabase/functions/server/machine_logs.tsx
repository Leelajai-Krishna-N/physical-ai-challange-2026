// Helper for the machine_logs table
// Schema: timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP, machine_id VARCHAR(50), current_data TEXT
import { createClient } from "jsr:@supabase/supabase-js@2.49.8";

const client = () =>
  createClient(
    Deno.env.get("SUPABASE_URL"),
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY"),
  );

// Insert a log row — returns the inserted row (with DB-generated timestamp)
export async function insertLog(
  machineId: string,
  currentData: Record<string, any>,
  customTimestamp?: string,
): Promise<{ timestamp: string; machine_id: string; current_data: string } | null> {
  const supabase = client();
  const row: any = {
    machine_id: machineId,
    current_data: JSON.stringify(currentData),
  };
  if (customTimestamp) {
    row.timestamp = customTimestamp;
  }
  const { data, error } = await supabase
    .from("machine_logs")
    .insert(row)
    .select("*")
    .single();
  if (error) {
    console.log(`Error inserting into machine_logs: ${error.message}`);
    return null;
  }
  return data;
}

// Get logs for a specific machine
export async function getLogsByMachine(machineId: string, limit = 100): Promise<any[]> {
  const supabase = client();
  const { data, error } = await supabase
    .from("machine_logs")
    .select("*")
    .eq("machine_id", machineId)
    .order("timestamp", { ascending: false })
    .limit(limit);
  if (error) {
    console.log(`Error reading machine_logs: ${error.message}`);
    return [];
  }
  return data || [];
}

// Get all recent logs
export async function getRecentLogs(limit = 200): Promise<any[]> {
  const supabase = client();
  const { data, error } = await supabase
    .from("machine_logs")
    .select("*")
    .order("timestamp", { ascending: false })
    .limit(limit);
  if (error) {
    console.log(`Error reading machine_logs: ${error.message}`);
    return [];
  }
  return data || [];
}

// Get logs by type for a machine (searches inside current_data JSON)
export async function getLogsByType(machineId: string, type: string): Promise<any[]> {
  const supabase = client();
  const { data, error } = await supabase
    .from("machine_logs")
    .select("*")
    .eq("machine_id", machineId)
    .like("current_data", `%"type":"${type}"%`)
    .order("timestamp", { ascending: false })
    .limit(10);
  if (error) {
    console.log(`Error reading machine_logs by type: ${error.message}`);
    return [];
  }
  return data || [];
}
