import { Hono } from "npm:hono";
import { cors } from "npm:hono/cors";
import { logger } from "npm:hono/logger";
import { insertLog, getLogsByMachine, getRecentLogs, getLogsByType } from "./machine_logs.tsx";
import * as kv from "./kv_store.tsx";
import { randomUUID } from "node:crypto";

const app = new Hono();

app.use("*", logger(console.log));

app.use(
  "/*",
  cors({
    origin: "*",
    allowHeaders: ["Content-Type", "Authorization"],
    allowMethods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    exposeHeaders: ["Content-Length"],
    maxAge: 600,
  }),
);

// ─── Key prefixes (simulate tables via kv_store) ───
// industrial_alert_events   → key: "alert_event:{uuid}"
// industrial_maintenance    → key: "maintenance:{uuid}"
// machine_power_state       → key: "power:{machine_id}"
// stopped_machines          → key: "stopped:{machine_id}"

// ─── Health check ───
app.get("/make-server-5eb58738/health", (c) => c.json({ status: "ok", version: "3.0" }));

// ─── Store a sensor reading (raw telemetry → machine_logs) ───
app.post("/make-server-5eb58738/store-reading", async (c) => {
  try {
    const body = await c.req.json();
    const { machine_id } = body;
    if (!machine_id) return c.json({ error: "machine_id required" }, 400);

    const row = await insertLog(machine_id, {
      type: "reading",
      z_score: null,
      parameters: {
        temperature_C: body.temperature_C,
        vibration_mm_s: body.vibration_mm_s,
        rpm: body.rpm,
        current_A: body.current_A,
      },
      status: body.status || "running",
    });

    return c.json({ success: true, timestamp: row?.timestamp || null });
  } catch (e) {
    console.log("Error storing reading:", e);
    return c.json({ error: `Failed to store reading: ${e}` }, 500);
  }
});

// ─── Store alert event (kv: alert_event:{id}) ───
app.post("/make-server-5eb58738/store-alert", async (c) => {
  try {
    const body = await c.req.json();
    const mid = body.machineId || body.machine_id;
    if (!mid) return c.json({ error: "machine_id required" }, 400);

    const eventId = randomUUID();
    const now = new Date().toISOString();

    // Build structured alert event matching the spec
    const alertEvent = {
      id: eventId,
      machine_id: mid,
      event_timestamp: now,
      final_status: body.severity === "critical" ? "CRITICAL" : "WARNING",
      operating_phase: body.operating_phase || null,
      pattern_key: body.pattern_key || null,
      fleet_event_type: body.fleet_event_type || null,
      current_metrics: body.parameters || null,
      metric_scores: body.metric_scores || null,
      trend_metrics: body.trend_metrics || null,
      persistence_metrics: body.persistence_metrics || null,
      risk_score: body.risk_score ?? null,
      remaining_life_minutes: body.remaining_life_minutes ?? null,
      health_stage: body.health_stage || null,
      priority_score_math: body.priority_score_math ?? null,
      priority_rank: body.priority_rank ?? null,
      ticket_action: body.ticket_action || null,
      priority_reason: body.priority_reason || null,
      top_ticket: body.is_top_ticket || false,
      should_shutdown: body.should_shutdown || false,
      shutdown_reason: body.shutdown_reason || null,
      llm_decision: body.llm_decision || null,
      z_scores: body.zScores || null,
      reason: body.reason || null,
      severity: body.severity || "warning",
      alert_id_frontend: body.id || null,
      source: "kairos-dashboard",
      created_at: now,
    };

    // Store in kv_store
    await kv.set(`alert_event:${eventId}`, alertEvent);

    // Also log to machine_logs for raw audit trail
    await insertLog(mid, {
      type: "alert",
      alert_event_id: eventId,
      z_score: body.zScores || null,
      severity: body.severity,
      reason: body.reason,
      parameters: body.parameters || null,
      risk_score: body.risk_score ?? null,
      health_stage: body.health_stage || null,
    });

    return c.json({ success: true, alert_event_id: eventId, timestamp: now });
  } catch (e) {
    console.log("Error storing alert event:", e);
    return c.json({ error: `Failed to store alert: ${e}` }, 500);
  }
});

// ─── Get all alert events ───
app.get("/make-server-5eb58738/alert-events", async (c) => {
  try {
    const machineId = c.req.query("machine_id");
    const events = await kv.getByPrefix("alert_event:");

    let filtered = events;
    if (machineId) {
      filtered = events.filter((e: any) => e.machine_id === machineId);
    }

    // Sort by event_timestamp descending
    filtered.sort((a: any, b: any) => new Date(b.event_timestamp).getTime() - new Date(a.event_timestamp).getTime());

    const limitStr = c.req.query("limit");
    const limit = limitStr ? parseInt(limitStr, 10) : 100;
    filtered = filtered.slice(0, limit);

    return c.json({ alert_events: filtered, count: filtered.length });
  } catch (e) {
    console.log("Error fetching alert events:", e);
    return c.json({ alert_events: [], count: 0, error: `${e}` });
  }
});

// ─── Create maintenance schedule (kv: maintenance:{id}) ───
app.post("/make-server-5eb58738/schedule-maintenance", async (c) => {
  try {
    const body = await c.req.json();
    const { machine_id, reason, alert_id, severity, zScores, reading,
            risk_score, remaining_life_minutes, pattern_key, health_stage,
            alert_event_id, should_shutdown } = body;
    if (!machine_id) return c.json({ error: "machine_id required" }, 400);

    const scheduleId = randomUUID();
    const now = new Date().toISOString();

    // Pick a maintenance slot (30 min from now by default)
    const slotDate = new Date(Date.now() + 30 * 60 * 1000);
    const slot = slotDate.toISOString();

    // Assign a technician based on machine type
    const techMap: Record<string, string> = {
      CNC_01: "T. Rodriguez — CNC Specialist",
      CNC_02: "M. Nakamura — CNC Lead",
      PUMP_03: "K. Johansson — Hydraulics",
      CONVEYOR_04: "A. Singh — Mechanical",
    };
    const technician = techMap[machine_id] || "On-call Engineer";

    // Estimate downtime based on severity
    const estimatedDowntime = severity === "critical" ? 120 : 60;

    // Action plan based on pattern
    const actionPlan: string[] = [];
    if (pattern_key === "bearing_wear") {
      actionPlan.push("Inspect spindle bearings", "Check lubrication system", "Measure shaft runout", "Replace bearings if tolerance exceeded");
    } else if (pattern_key === "thermal_runaway") {
      actionPlan.push("Check coolant flow", "Inspect thermal paste", "Verify fan operation", "Test thermal cutoff sensors");
    } else if (pattern_key === "cavitation_clog") {
      actionPlan.push("Check inlet strainer", "Inspect impeller", "Verify NPSH conditions", "Flush system lines");
    } else {
      actionPlan.push("General diagnostic inspection", "Verify sensor calibration", "Check electrical connections", "Run baseline test cycle");
    }

    const maintenanceRecord = {
      id: scheduleId,
      machine_id,
      alert_event_id: alert_event_id || alert_id || null,
      maintenance_decision: "schedule_now",
      maintenance_slot_preference: "immediate",
      scheduled_slot: slot,
      technician,
      status: "pending_confirmation",
      actions: actionPlan,
      estimated_downtime_minutes: estimatedDowntime,
      should_shutdown: should_shutdown ?? (severity === "critical"),
      shutdown_at: null,
      shutdown_reason: reason || "Critical fault detected — automatic maintenance scheduled",
      reason: reason || "Critical fault detected — automatic maintenance scheduled",
      risk_score: risk_score ?? null,
      remaining_life_minutes: remaining_life_minutes ?? null,
      pattern_key: pattern_key || null,
      health_stage: health_stage || null,
      severity: severity || "critical",
      llm_decision: null,
      created_at: now,
      confirmed_at: null,
    };

    // Store in kv_store
    await kv.set(`maintenance:${scheduleId}`, maintenanceRecord);

    // Also log to machine_logs for audit
    await insertLog(machine_id, {
      type: "maintenance_scheduled",
      maintenance_id: scheduleId,
      z_score: zScores || null,
      parameters: reading || null,
      severity,
      reason: maintenanceRecord.reason,
      technician,
      scheduled_slot: slot,
      estimated_downtime_minutes: estimatedDowntime,
      actions: actionPlan,
    });

    // Build the frontend-compatible schedule object
    const schedule = {
      id: scheduleId,
      machine_id,
      reason: maintenanceRecord.reason,
      status: "pending_confirmation" as const,
      created_at: now,
      confirmed_at: null,
      technician,
      scheduled_slot: slot,
      estimated_downtime_minutes: estimatedDowntime,
      actions: actionPlan,
      risk_score: risk_score ?? null,
      pattern_key: pattern_key || null,
    };

    return c.json({ success: true, schedule, timestamp: now });
  } catch (e) {
    console.log("Error creating maintenance schedule:", e);
    return c.json({ error: `Failed to create schedule: ${e}` }, 500);
  }
});

// ─── Confirm maintenance (after n8n webhook 2xx) ───
app.post("/make-server-5eb58738/confirm-maintenance", async (c) => {
  try {
    const body = await c.req.json();
    const { schedule_id, machine_id, webhook_response } = body;
    if (!machine_id) return c.json({ error: "machine_id required" }, 400);

    const now = new Date().toISOString();

    // Update maintenance record in kv_store
    if (schedule_id) {
      const existing = await kv.get(`maintenance:${schedule_id}`);
      if (existing) {
        existing.status = "confirmed";
        existing.confirmed_at = now;
        existing.shutdown_at = now;
        existing.llm_decision = webhook_response || null;
        await kv.set(`maintenance:${schedule_id}`, existing);
      }
    }

    // Mark machine as stopped in kv_store
    await kv.set(`stopped:${machine_id}`, {
      machine_id,
      stopped_at: now,
      schedule_id: schedule_id || null,
      reason: "Maintenance confirmed by n8n — machine halted",
      power_state: "SHUTDOWN",
    });

    // Update power state
    await kv.set(`power:${machine_id}`, {
      machine_id,
      state: "SHUTDOWN",
      since: now,
      reason: "Maintenance confirmed",
    });

    // Audit trail in machine_logs
    await insertLog(machine_id, {
      type: "maintenance_confirmed",
      maintenance_id: schedule_id,
      webhook_response: typeof webhook_response === "string" ? webhook_response : JSON.stringify(webhook_response),
    });

    await insertLog(machine_id, {
      type: "machine_halted",
      maintenance_id: schedule_id,
      reason: "Maintenance confirmed by n8n — machine halted",
      power_state: "SHUTDOWN",
    });

    return c.json({ success: true, machine_id, status: "stopped", timestamp: now });
  } catch (e) {
    console.log("Error confirming maintenance:", e);
    return c.json({ error: `Failed to confirm maintenance: ${e}` }, 500);
  }
});

// ─── Get stopped machines ───
app.get("/make-server-5eb58738/stopped-machines", async (c) => {
  try {
    const stoppedRecords = await kv.getByPrefix("stopped:");
    const stopped: Record<string, any> = {};
    for (const rec of stoppedRecords) {
      if (rec && rec.machine_id) {
        stopped[rec.machine_id] = rec;
      }
    }
    return c.json({ stopped_machines: stopped });
  } catch (e) {
    console.log("Error fetching stopped machines:", e);
    return c.json({ stopped_machines: {} });
  }
});

// ─── Resume a machine ───
app.post("/make-server-5eb58738/resume-machine", async (c) => {
  try {
    const { machine_id } = await c.req.json();
    if (!machine_id) return c.json({ error: "machine_id required" }, 400);

    // Remove stopped state
    try { await kv.del(`stopped:${machine_id}`); } catch {}

    // Update power state
    await kv.set(`power:${machine_id}`, {
      machine_id,
      state: "RUNNING",
      since: new Date().toISOString(),
      reason: "Resumed by operator",
    });

    // Audit trail
    await insertLog(machine_id, {
      type: "machine_resumed",
      power_state: "RUNNING",
    });

    return c.json({ success: true, machine_id, status: "resumed" });
  } catch (e) {
    console.log("Error resuming machine:", e);
    return c.json({ error: `Failed to resume machine: ${e}` }, 500);
  }
});

// ─── Store webhook response ───
app.post("/make-server-5eb58738/store-webhook-response", async (c) => {
  try {
    const body = await c.req.json();
    const wrId = randomUUID();
    const now = new Date().toISOString();

    // Store in kv_store
    await kv.set(`webhook_response:${wrId}`, {
      id: wrId,
      machine_id: body.machine_id,
      schedule_id: body.schedule_id || null,
      event: body.event || "webhook_response",
      status_code: body.status,
      body: body.body,
      received_at: body.received_at || now,
    });

    // Audit trail
    await insertLog(body.machine_id || "SYSTEM", {
      type: "webhook_response",
      webhook_id: wrId,
      status_code: body.status,
      schedule_id: body.schedule_id || null,
    });

    return c.json({ success: true, webhook_response_id: wrId, timestamp: now });
  } catch (e) {
    console.log("Error storing webhook response:", e);
    return c.json({ error: `Failed to store webhook response: ${e}` }, 500);
  }
});

// ─── Get maintenance schedules ───
app.get("/make-server-5eb58738/maintenance-schedules", async (c) => {
  try {
    const machineId = c.req.query("machine_id");
    const records = await kv.getByPrefix("maintenance:");

    let filtered = records;
    if (machineId) {
      filtered = records.filter((r: any) => r.machine_id === machineId);
    }

    // Sort by created_at descending
    filtered.sort((a: any, b: any) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());

    const limitStr = c.req.query("limit");
    const limit = limitStr ? parseInt(limitStr, 10) : 50;
    filtered = filtered.slice(0, limit);

    return c.json({ schedules: filtered, count: filtered.length });
  } catch (e) {
    console.log("Error fetching maintenance schedules:", e);
    return c.json({ schedules: [], count: 0, error: `${e}` });
  }
});

// ─── Get power states for all machines ───
app.get("/make-server-5eb58738/power-states", async (c) => {
  try {
    const states = await kv.getByPrefix("power:");
    const result: Record<string, any> = {};
    for (const s of states) {
      if (s && s.machine_id) result[s.machine_id] = s;
    }
    return c.json({ power_states: result });
  } catch (e) {
    console.log("Error fetching power states:", e);
    return c.json({ power_states: {} });
  }
});

// ─── Get webhook responses ───
app.get("/make-server-5eb58738/webhook-responses", async (c) => {
  try {
    const responses = await kv.getByPrefix("webhook_response:");
    responses.sort((a: any, b: any) => new Date(b.received_at).getTime() - new Date(a.received_at).getTime());
    const limitStr = c.req.query("limit");
    const limit = limitStr ? parseInt(limitStr, 10) : 50;
    return c.json({ responses: responses.slice(0, limit), count: responses.length });
  } catch (e) {
    console.log("Error fetching webhook responses:", e);
    return c.json({ responses: [], count: 0 });
  }
});

// ─── Get machine logs (raw telemetry from machine_logs table) ───
app.get("/make-server-5eb58738/machine-logs", async (c) => {
  try {
    const machineId = c.req.query("machine_id");
    const limitStr = c.req.query("limit");
    const limit = limitStr ? parseInt(limitStr, 10) : 200;

    if (machineId) {
      const logs = await getLogsByMachine(machineId, limit);
      return c.json({ logs });
    } else {
      const logs = await getRecentLogs(limit);
      return c.json({ logs });
    }
  } catch (e) {
    console.log("Error fetching machine logs:", e);
    return c.json({ logs: [], error: `Failed to fetch logs: ${e}` }, 500);
  }
});

// ─── Clear dashboard state (fresh start on page load) ───
app.post("/make-server-5eb58738/clear-dashboard-state", async (c) => {
  try {
    const [stoppedRecords, maintenanceRecords, alertRecords, webhookRecords] = await Promise.all([
      kv.getByPrefix("stopped:"),
      kv.getByPrefix("maintenance:"),
      kv.getByPrefix("alert_event:"),
      kv.getByPrefix("webhook_response:"),
    ]);

    const keysToDelete: string[] = [];
    for (const rec of stoppedRecords) {
      if (rec?.machine_id) keysToDelete.push(`stopped:${rec.machine_id}`);
    }
    for (const rec of maintenanceRecords) {
      if (rec?.id) keysToDelete.push(`maintenance:${rec.id}`);
    }
    for (const rec of alertRecords) {
      if (rec?.id) keysToDelete.push(`alert_event:${rec.id}`);
    }
    for (const rec of webhookRecords) {
      if (rec?.id) keysToDelete.push(`webhook_response:${rec.id}`);
    }

    if (keysToDelete.length > 0) {
      await kv.mdel(keysToDelete);
    }

    console.log(`Cleared dashboard state: ${keysToDelete.length} keys deleted`);
    return c.json({ cleared: keysToDelete.length });
  } catch (e) {
    console.log("Error clearing dashboard state:", e);
    return c.json({ cleared: 0, error: String(e) });
  }
});

// ─── Dashboard summary (single call for all state) ───
app.get("/make-server-5eb58738/dashboard-state", async (c) => {
  try {
    const [stoppedRecords, powerStates, alertEvents, schedules] = await Promise.all([
      kv.getByPrefix("stopped:"),
      kv.getByPrefix("power:"),
      kv.getByPrefix("alert_event:"),
      kv.getByPrefix("maintenance:"),
    ]);

    const stopped: Record<string, any> = {};
    for (const rec of stoppedRecords) {
      if (rec?.machine_id) stopped[rec.machine_id] = rec;
    }

    const power: Record<string, any> = {};
    for (const rec of powerStates) {
      if (rec?.machine_id) power[rec.machine_id] = rec;
    }

    // Recent alerts (last 50)
    const recentAlerts = alertEvents
      .sort((a: any, b: any) => new Date(b.event_timestamp).getTime() - new Date(a.event_timestamp).getTime())
      .slice(0, 50);

    // Recent schedules (last 20)
    const recentSchedules = schedules
      .sort((a: any, b: any) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())
      .slice(0, 20);

    return c.json({
      stopped_machines: stopped,
      power_states: power,
      recent_alerts: recentAlerts,
      recent_schedules: recentSchedules,
      counts: {
        total_alerts: alertEvents.length,
        total_schedules: schedules.length,
        stopped_count: Object.keys(stopped).length,
      },
    });
  } catch (e) {
    console.log("Error fetching dashboard state:", e);
    return c.json({ stopped_machines: {}, power_states: {}, recent_alerts: [], recent_schedules: [], counts: {} });
  }
});

// Legacy compat routes
app.get("/make-server-5eb58738/alerts", async (c) => {
  try {
    const events = await kv.getByPrefix("alert_event:");
    events.sort((a: any, b: any) => new Date(b.event_timestamp).getTime() - new Date(a.event_timestamp).getTime());
    return c.json({ alerts: events.slice(0, 100) });
  } catch (e) {
    console.log("Error fetching alerts:", e);
    return c.json({ alerts: [] });
  }
});

app.get("/make-server-5eb58738/schedules", async (c) => {
  try {
    const records = await kv.getByPrefix("maintenance:");
    records.sort((a: any, b: any) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
    return c.json({ schedules: records.slice(0, 50) });
  } catch (e) {
    console.log("Error fetching schedules:", e);
    return c.json({ schedules: [] });
  }
});

Deno.serve(app.fetch);